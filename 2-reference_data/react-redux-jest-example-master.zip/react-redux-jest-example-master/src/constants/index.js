export const INCREMENT = '/App/INCREMENT';
export const DECREMENT = '/App/DECREMENT';
