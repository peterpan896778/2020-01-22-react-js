If you want to use a Logo you have to import from `src/components`:
```javascript
import { Logo } from 'src/components';
```

Logo:

    <Logo />
