If you want to use a Counter you have to import from `src/components`:
```javascript
import { Counter } from 'src/components';
```

Counter without value:

    <Counter />

Counter with value:

    <Counter value="30" />
