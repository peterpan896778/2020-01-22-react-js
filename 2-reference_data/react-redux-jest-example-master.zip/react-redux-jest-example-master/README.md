# React Redux Jest Example
Testing React/Redux with Jest, Styleguidist and Snapguidist

## Install
To install simply write `yarn`

## Run app
To run simply write `yarn start`

## Run Jest
To run Jest tests write `yarn test`

## Run Styleguidist
To run Styleguidist write `yarn styleguide`