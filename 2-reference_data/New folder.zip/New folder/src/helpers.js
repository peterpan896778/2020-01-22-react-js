import moment from 'moment';
import ReactHtmlParser from 'react-html-parser';

moment.updateLocale('en', {
  relativeTime: {
    future: 'in %s',
    past: '%s',
    s: '',
    ss: '%ss',
    m: '1m',
    mm: '%dm',
    h: '1h',
    hh: '%dh',
    d: '1d',
    dd: '%dd',
    M: '1m',
    MM: '%dM',
    y: '1y',
    yy: '%dY'
  }
});


export const transformMentions = body => ReactHtmlParser(body.replace(/@(\[[^ ]*\]\([^ ]*?\))/g,
  mention => `<a class="mention">@${mention.match(/\[(.*)\]/)[1]}</a>`
));

export const getUsername = (user) => user ? user.username.split('.')[0] : '';
