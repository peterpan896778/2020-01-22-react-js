import React from 'react';
import ReactDOM from 'react-dom';

import 'react-perfect-scrollbar/dist/css/styles.css';
import './assets/css/normalize.css';
import './assets/css/app.css';
import './assets/css/editor.css';

import App from './app/App';

ReactDOM.render(<App />, document.getElementById('root'));
