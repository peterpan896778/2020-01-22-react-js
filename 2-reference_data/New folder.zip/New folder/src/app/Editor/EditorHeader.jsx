/* eslint-disable jsx-a11y/control-has-associated-label */
import React from 'react';

import * as S from './styled';

const EditorHeader = props => {
  const { preview, publish, back } = props;
  return (
    <div className="content-header__wrapper">
      <header className="editor content-header">
        <div className="content-header__left">
          <button
            type="button"
            className="back"
            name="button"
            onClick={() => back()}
          />
          <div>
            <p className="content-title">Dropbox.design</p>
            <p>
              <span className="users-count">28 960</span>
              <span>Blockstack Team Directory</span>
            </p>
          </div>
        </div>
        <div className="content-header__right">
          <div className="content-header__more-wrapper">
            <button type="button" className="more-btn" name="button" data-toggle="dropdown" />
            <ul className="content-header__more dropdown-menu">
              <li>
                  Settings
              </li>
              <li>
                  Private
              </li>
              <li>
                  Invite users
              </li>
              <li>
                  Set password
              </li>
              <li>
                  Delete story
              </li>
            </ul>
          </div>
          <S.PreviewButton onClick={() => preview()}>Preview</S.PreviewButton>
          <S.PublishButton onClick={() => publish()}>Publish</S.PublishButton>
        </div>
      </header>
    </div>
  );
};

export default EditorHeader;
