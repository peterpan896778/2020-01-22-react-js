/* eslint-disable camelcase */
import React, { Component } from 'react';
import ReactMarkdown from 'react-markdown';

import EditorHeader from './EditorHeader';
import EditorContent from './EditorContent';

import * as S from './styled';

class Editor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show_preview: false,
      content: '',
    };
    this.previewContent = this.previewContent.bind(this);
  }

  handleContentChange = (value) => {
    console.log('value', value)
    this.setState({
      content: value
    });
  }

  previewContent = () => {
    this.setState({ show_preview: true });
  }

  backContent = () => {
    this.setState({ show_preview: false });
  }

  render() {
    const { show_preview, content } = this.state;

    return (
      <S.Container>
        <EditorHeader
          preview={this.previewContent}
          back={this.backContent}
        />
        {show_preview ?
          <S.Content>
            <ReactMarkdown
              source={content}
              escapeHtml={false}
            />
          </S.Content> :
          <EditorContent
            content={content}
            handleContentChange={this.handleContentChange}
          />
        }
      </S.Container>
    );
  }
}

export default Editor;
