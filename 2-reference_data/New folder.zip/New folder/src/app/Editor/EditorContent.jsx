/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable eqeqeq */
/* eslint-disable camelcase */
/* eslint-disable jsx-a11y/control-has-associated-label */
import React from 'react';
import ReactQuill from 'react-quill';
import mdu from 'markdown-utils';

import * as S from './styled';

class EditorContent extends React.Component {
  constructor(props) {
    super(props);
    const { content } = this.props;
    this.state = { content };
    this.quillRef = null; // Quill instance
    this.reactQuillRef = null; // ReactQuill component
  }

  componentDidMount() {
    this.attachQuillRefs();
  }

  componentDidUpdate() {
    this.attachQuillRefs();
  }

  attachQuillRefs = () => {
    if (typeof this.reactQuillRef.getEditor !== 'function') return;
    this.quillRef = this.reactQuillRef.getEditor();
  }

  handleChange = () => {
    const { handleContentChange } = this.props;
    const ref = this.quillRef;
    if (ref) {
      const content = ref.getText();
      console.log('content', content)
     
    }
  }

  render() {
    const { content } = this.state;
    const upload_text = 'Use photos or videos from Tweets in the moment, or upload any images';
    return (
      <>
        <S.ContentContainer>
          <S.ContentTitle type="text" name="" placeholder="Enter your title" />
          <S.ContentUpload className="editor-upload">
            <S.UploadChild>{upload_text}</S.UploadChild>
          </S.ContentUpload>
          <ReactQuill
            value={content}
            ref={(el) => { this.reactQuillRef = el; }}
            modules={EditorContent.modules}
            onChange={this.handleChange}
          />
        </S.ContentContainer>
        <CustomToolbar />
      </>
    );
  }
}

function bold() {
  const selection = this.quill.getSelection();
  const text = this.quill.getText(selection);
  const mark_down = mdu.strong(text);

  if (selection.length != 0) {
    const start = this.quill.getSelection().index;
    if (start == 0) {
      this.quill.updateContents([
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    } else {
      this.quill.updateContents([
        { retain: start },
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    }
    this.quill.setSelection(this.quill.getSelection().index + 2);
  }
}

function quote() {
  const selection = this.quill.getSelection();
  const text = this.quill.getText(selection);
  const mark_down = mdu.blockquote(text);

  if (selection.length != 0) {
    const start = this.quill.getSelection().index;
    if (start == 0) {
      this.quill.updateContents([
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    } else {
      this.quill.updateContents([
        { retain: start },
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    }
    this.quill.setSelection(this.quill.getSelection().index + 2);
  }
}

function big() {
  const selection = this.quill.getSelection();
  const text = this.quill.getText(selection);
  const mark_down = mdu.em(text);

  if (selection.length != 0) {
    const start = this.quill.getSelection().index;
    if (start == 0) {
      this.quill.updateContents([
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    } else {
      this.quill.updateContents([
        { retain: start },
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    }
    this.quill.setSelection(this.quill.getSelection().index);
  }
}

function small() {
  const selection = this.quill.getSelection();
  const text = this.quill.getText(selection);
  const mark_down = mdu.em(text);

  if (selection.length != 0) {
    const start = this.quill.getSelection().index;
    if (start == 0) {
      this.quill.updateContents([
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    } else {
      this.quill.updateContents([
        { retain: start },
        { delete: selection.length },
        { insert: mark_down }
      ]
      );
    }
    this.quill.setSelection(this.quill.getSelection().index);
  }
}

/*
 * Custom toolbar component including insertStar button and dropdowns
 */
const CustomToolbar = () => (
  <S.OptionMenuContainer>
    <S.OptionMenu id="toolbar">
        <S.ButtonBold type="button" name="button" />
        <S.ButtonQuote type="button" name="button" />
        <S.ButtonBig type="button" name="button" />
        <S.ButtonSmall type="button" name="button" />
        <S.ButtonList type="button" name="button" />
        <S.ButtonVideo type="button" name="button" />
        <S.ButtonAttach type="button" name="button" />
        <S.ButtonImage type="button" name="button" />
        <S.ButtonSmile type="button" name="button" />
    </S.OptionMenu>
  </S.OptionMenuContainer>
);

EditorContent.modules = {
  toolbar: {
    container: '#toolbar',
    handlers: {
      bold, quote, big, small,
    }
  },
  clipboard: {
    matchVisual: false,
  }
};

export default EditorContent;
