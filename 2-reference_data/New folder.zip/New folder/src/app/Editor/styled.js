import styled from 'styled-components';

// eslint-disable-next-line import/prefer-default-export
export const Container = styled.div`
  position: relative;
  width: 100%;
`;

export const Content = styled.div`
  width: 748px;
  margin: 45px auto 0;
`;
export const PreviewButton = styled.button`
  border: 1px solid #bababa;
  line-height: 37px;
  margin-left: 15px;
`;

export const PublishButton = styled.button`
  color: #fff;
  line-height: 38px;
  background: #5c24d4;
  margin-left: 12px;
`;

export const ContentContainer = styled.div`
  width: 748px;
  margin: 45px auto 0;
`;

export const ContentTitle = styled.input`
  display: block;
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 40px;
`;

export const ContentUpload = styled.div`
  width: 100%;
  height: 139px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -ms-flex-direction: column;
  flex-direction: column;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  background: #f8f8f8;
  margin-top: 34px;
  cursor: pointer;
  transition: background 0.2s ease-in-out;
  :before {
    content: "";
    display: block;
    width: 22px;
    height: 22px;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='45px' height='45px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M45.000,25.714 L25.714,25.714 L25.714,45.000 L19.286,45.000 L19.286,25.714 L-0.000,25.714 L-0.000,19.286 L19.286,19.286 L19.286,0.000 L25.714,0.000 L25.714,19.286 L45.000,19.286 L45.000,25.714 Z'/%3e%3c/svg%3e");
    background-size: cover;
    margin-bottom: 18px;
  }
`;

export const UploadChild = styled.p`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 14px;
  color: #616061;
`;

export const ContentText = styled.textarea`
  width: 100%;
  height: auto;
  max-height: 400px;
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 17px;
  line-height: 35px;
  margin-top: 32px;
  resize: none;
`;

export const OptionMenuContainer = styled.div`
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  width: calc(100% - 85px);
  position: fixed;
  left: 85px;
  bottom: 50px;
  transition: opacity 0.2s ease-in-out;
`;

export const OptionMenu = styled.div`
  height: 50px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  background: #1b1a1b;
  border-radius: 6px;
  padding: 0 15px;
  margin: 0 auto;
`;

export const ButtonBold = styled.button`
  width: 14px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='28px' height='38px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M0.003,0.003 L16.450,0.003 C19.678,0.003 22.254,0.891 24.175,2.665 C26.096,4.440 27.057,6.740 27.057,9.566 C27.057,11.271 26.636,12.827 25.794,14.231 C24.952,15.635 23.699,16.725 22.033,17.500 C24.371,18.396 25.247,19.586 26.347,21.068 C27.447,22.550 27.999,24.453 27.999,26.779 C27.999,30.053 26.832,32.741 24.502,34.843 C22.171,36.945 19.934,37.996 16.107,37.996 L0.003,37.996 L0.003,0.003 ZM5.844,16.079 L14.205,16.079 C16.891,16.079 18.158,15.584 19.407,14.593 C20.655,13.602 21.281,12.056 21.281,9.953 C21.281,8.144 20.690,6.766 19.508,5.818 C18.327,4.871 17.045,4.396 14.258,4.396 L5.844,4.396 L5.844,16.079 ZM5.844,33.601 L15.812,33.601 C18.463,33.601 19.470,32.977 20.796,31.727 C22.121,30.478 22.783,28.794 22.783,26.675 C22.783,24.521 22.045,22.914 20.565,21.854 C19.086,20.795 17.885,20.265 14.995,20.265 L5.843,20.265 L5.843,33.601 L5.844,33.601 Z'/%3e%3c/svg%3e");
  background-size: cover;
`;

export const ButtonQuote = styled.button`
  width: 21px;
  height: 15px;
  background-image: url("data:image/svg+xml;charset=UTF-8, %3csvg width='640px' height='458px' viewBox='0 0 640 458' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3e%3cg id='Page-1' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3e%3cg id='quotation' fill='%23858585' fill-rule='nonzero'%3e%3cpath d='M189.925781,457.75 L77.089844,457.75 L115.839844,295.25 L75,295.25 C33.640625,295.25 0,261.609375 0,220.25 L0,75.25 C0,33.894531 33.640625,0.25 75,0.25 L220,0.25 C261.359375,0.25 295,33.894531 295,75.25 L295,224.957031 C295,249.71875 288.789062,274.332031 277.039062,296.128906 L189.925781,457.75 Z M140.410156,407.75 L160.074219,407.75 L233.027344,272.402344 C240.859375,257.871094 245,241.464844 245,224.957031 L245,75.25 C245,61.464844 233.785156,50.25 220,50.25 L75,50.25 C61.214844,50.25 50,61.464844 50,75.25 L50,220.25 C50,234.035156 61.214844,245.25 75,245.25 L179.160156,245.25 L140.410156,407.75 Z M534.925781,457.75 L422.089844,457.75 L460.839844,295.25 L420,295.25 C378.640625,295.25 345,261.609375 345,220.25 L345,75.25 C345,33.894531 378.640625,0.25 420,0.25 L565,0.25 C606.359375,0.25 640,33.894531 640,75.25 L640,224.957031 C640,249.71875 633.789062,274.332031 622.039062,296.128906 L534.925781,457.75 Z M485.410156,407.75 L505.074219,407.75 L578.027344,272.402344 C585.859375,257.871094 590,241.464844 590,224.957031 L590,75.25 C590,61.464844 578.785156,50.25 565,50.25 L420,50.25 C406.214844,50.25 395,61.464844 395,75.25 L395,220.25 C395,234.035156 406.214844,245.25 420,245.25 L524.160156,245.25 L485.410156,407.75 Z' id='Shape'%3e%3c/path%3e%3c/g%3e%3c/g%3e%3c/svg%3e");
  background-size: cover;
  margin-left: 15px;
}
`;

export const ButtonBig = styled.button`
  width: 35px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='39px' height='39px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M38.986,1.207 C38.978,0.538 38.432,0.000 37.760,0.000 L1.234,0.000 C0.557,0.000 0.008,0.546 0.008,1.220 L0.008,7.931 C0.008,8.605 0.557,9.151 1.234,9.151 L4.004,9.151 C4.377,9.151 4.729,8.983 4.961,8.693 L7.045,6.101 L15.822,6.101 L15.822,37.780 C15.822,38.454 16.371,39.000 17.048,39.000 L21.952,39.000 C22.629,39.000 23.178,38.454 23.178,37.780 L23.178,6.101 L31.945,6.101 L34.039,8.695 C34.272,8.984 34.624,9.151 34.995,9.151 L37.765,9.151 C38.091,9.151 38.404,9.022 38.634,8.792 C38.864,8.562 38.992,8.250 38.991,7.925 L38.986,1.207 Z'/%3e%3c/svg%3e");
  background-size: 19px 19px;
  background-repeat: no-repeat;
  background-position: right bottom;
  border-left: 1px solid #494849;
  padding-left: 15px;
  margin-left: 15px;
`;

export const ButtonSmall = styled.button`
  width: 33px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='31px' height='31px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M30.989,0.959 C30.982,0.428 30.548,0.000 30.014,0.000 L0.981,0.000 C0.442,0.000 0.006,0.434 0.006,0.970 L0.006,6.304 C0.006,6.840 0.442,7.274 0.981,7.274 L3.183,7.274 C3.479,7.274 3.759,7.140 3.944,6.910 L5.600,4.849 L12.577,4.849 L12.577,30.030 C12.577,30.566 13.013,31.000 13.551,31.000 L17.449,31.000 C17.987,31.000 18.424,30.566 18.424,30.030 L18.424,4.849 L25.393,4.849 L27.057,6.912 C27.242,7.141 27.522,7.274 27.817,7.274 L30.018,7.274 C30.277,7.274 30.526,7.171 30.709,6.988 C30.892,6.805 30.994,6.558 30.993,6.300 L30.989,0.959 Z'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-size: 15px 15px;
  background-position: left bottom;
  border-right: 1px solid #494849;
  padding-right: 15px;
  margin-left: 15px;
`;

export const ButtonList = styled.button`
  width: 19px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='38px' height='38px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M12.022,33.922 L12.022,30.952 L38.005,30.952 L38.005,33.922 L12.022,33.922 ZM12.022,17.515 L38.005,17.515 L38.005,20.485 L12.022,20.485 L12.022,17.515 ZM12.022,3.707 L38.005,3.707 L38.005,6.677 L12.022,6.677 L12.022,3.707 ZM5.337,31.242 C6.794,32.279 7.472,33.248 7.472,34.293 C7.472,36.340 5.807,38.005 3.760,38.005 L-0.005,38.005 L-0.005,35.035 L3.760,35.035 C4.117,35.035 4.425,34.768 4.490,34.426 C4.215,34.048 3.206,33.320 2.290,32.851 L1.481,32.437 L1.480,30.849 L2.509,29.839 L-0.005,29.839 L-0.005,26.869 L7.567,26.869 L7.567,29.035 L5.327,31.234 C5.330,31.237 5.334,31.239 5.337,31.242 ZM-0.005,22.028 L0.423,21.595 C0.433,21.585 1.407,20.597 2.421,19.447 C3.961,17.701 4.386,16.954 4.493,16.729 C4.434,16.381 4.122,16.105 3.760,16.105 L-0.005,16.105 L-0.005,13.135 L3.760,13.135 C5.807,13.135 7.472,14.800 7.472,16.847 C7.472,17.640 7.026,18.680 4.854,21.177 C4.817,21.218 4.781,21.260 4.744,21.301 L7.567,21.301 L7.567,24.271 L-0.005,24.271 L-0.005,22.028 ZM2.297,-0.005 L5.266,-0.005 L5.266,10.389 L2.297,10.389 L2.297,-0.005 Z'/%3e%3c/svg%3e");
  background-size: cover;
  margin-left: 15px;
  position: relative;
`;

export const ButtonVideo = styled.button`
  width: 20px;
  height: 14px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='41px' height='28px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M28.349,8.352 L28.349,4.739 C28.349,2.121 26.193,-0.010 23.543,-0.010 L4.802,-0.010 C2.153,-0.010 -0.003,2.121 -0.003,4.739 L-0.003,23.261 C-0.003,25.879 2.153,28.010 4.802,28.010 L23.543,28.010 C26.193,28.010 28.349,25.879 28.349,23.261 L28.349,19.728 L41.003,25.981 L41.003,2.099 L28.349,8.352 ZM25.145,23.261 C25.145,24.134 24.427,24.844 23.543,24.844 L4.802,24.844 C3.919,24.844 3.200,24.134 3.200,23.261 L3.200,4.739 C3.200,3.866 3.919,3.156 4.802,3.156 L23.543,3.156 C24.427,3.156 25.145,3.866 25.145,4.739 L25.145,23.261 ZM37.800,20.858 L28.349,16.188 L28.349,11.892 L37.800,7.221 L37.800,20.858 Z'/%3e%3c/svg%3e");
  background-size: cover;  
  margin-left: 30px;
`;

export const ButtonAttach = styled.button`
  width: 20px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='40px' height='38px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M36.254,3.753 C31.269,-1.251 23.156,-1.251 18.170,3.753 L2.669,19.312 C-0.892,22.886 -0.892,28.702 2.670,32.277 C4.450,34.064 6.789,34.958 9.128,34.957 C11.467,34.957 13.806,34.064 15.587,32.277 L29.796,18.015 C31.933,15.870 31.933,12.381 29.796,10.236 C27.659,8.091 24.182,8.091 22.046,10.236 L12.753,19.562 C12.040,20.278 12.040,21.439 12.753,22.155 C13.467,22.871 14.623,22.871 15.337,22.155 L24.629,12.829 C25.341,12.114 26.500,12.114 27.213,12.828 C27.925,13.544 27.925,14.707 27.212,15.422 L13.003,29.684 C10.866,31.828 7.390,31.829 5.253,29.684 C3.116,27.539 3.116,24.049 5.252,21.904 L20.754,6.346 C24.315,2.772 30.110,2.772 33.671,6.346 C35.396,8.078 36.346,10.380 36.346,12.829 C36.346,15.278 35.396,17.580 33.671,19.311 L18.170,34.870 C17.457,35.586 17.457,36.747 18.170,37.463 C18.527,37.821 18.994,38.000 19.462,38.000 C19.929,38.000 20.397,37.821 20.754,37.463 L36.254,21.904 C38.670,19.480 40.000,16.257 40.000,12.829 C40.000,9.400 38.670,6.177 36.254,3.753 Z'/%3e%3c/svg%3e");
  background-size: cover;
  margin-left: 15px;
`;

export const ButtonImage = styled.button`
  width: 21px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8, %3csvg width='512px' height='477px' viewBox='0 0 512 477' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3e%3cg id='Page-1' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3e%3cg id='add' fill='%23858585' fill-rule='nonzero'%3e%3cpath d='M512,60.054688 L512,312.28125 L471.964844,312.28125 L471.964844,60.054688 C471.964844,49.015625 462.984375,40.035156 451.945312,40.035156 L60.054688,40.035156 C49.015625,40.035156 40.035156,49.015625 40.035156,60.054688 L40.035156,211.539062 L122.855469,90.496094 L189.285156,173.53125 L219.386719,130.261719 L347.851562,297.265625 L347.851562,312.28125 L308.890625,312.28125 L221.011719,198.035156 L108.515625,359.746094 L75.648438,336.882812 L165.4375,207.8125 L125.367188,157.726562 L40.035156,282.441406 L40.035156,380.34375 C40.035156,391.378906 49.015625,400.359375 60.054688,400.359375 L264.777344,400.359375 L264.777344,440.398438 L60.054688,440.398438 C26.941406,440.398438 -2.84217094e-14,413.457031 -2.84217094e-14,380.34375 L-2.84217094e-14,60.054688 C-2.84217094e-14,26.941406 26.941406,-1.13686838e-13 60.054688,-1.13686838e-13 L451.945312,-1.13686838e-13 C485.058594,-1.13686838e-13 512,26.9375 512,60.054688 L512,60.054688 Z M377.878906,192.171875 C344.765625,192.171875 317.824219,165.230469 317.824219,132.117188 C317.824219,99.003906 344.765625,72.0625 377.878906,72.0625 C410.992188,72.0625 437.933594,99.003906 437.933594,132.117188 C437.933594,165.230469 410.992188,192.171875 377.878906,192.171875 Z M397.898438,132.117188 C397.898438,121.078125 388.917969,112.101562 377.878906,112.101562 C366.839844,112.101562 357.859375,121.078125 357.859375,132.117188 C357.859375,143.15625 366.839844,152.136719 377.878906,152.136719 C388.917969,152.136719 397.898438,143.15625 397.898438,132.117188 Z M427.925781,268.242188 L387.886719,268.242188 L387.886719,352.316406 L303.8125,352.316406 L303.8125,392.351562 L387.886719,392.351562 L387.886719,476.429688 L427.925781,476.429688 L427.925781,392.351562 L512,392.351562 L512,352.316406 L427.925781,352.316406 L427.925781,268.242188 Z' id='Shape'%3e%3c/path%3e%3c/g%3e%3c/g%3e%3c/svg%3e");
  background-size: cover;
  margin-left: 15px;
`;

export const ButtonSmile = styled.button`
  width: 19px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='38px' height='38px'%3e%3cpath fill-rule='evenodd' fill='rgb(133, 133, 133)' d='M32.440,5.530 C25.020,-1.887 12.949,-1.887 5.531,5.529 C-1.888,12.945 -1.887,25.013 5.532,32.430 C12.949,39.845 25.020,39.845 32.439,32.428 C39.857,25.013 39.856,12.946 32.440,5.530 ZM30.363,30.354 C24.090,36.626 13.881,36.627 7.607,30.355 C1.332,24.082 1.332,13.875 7.607,7.603 C13.881,1.332 24.089,1.331 30.364,7.604 C36.638,13.876 36.637,24.082 30.363,30.354 ZM11.888,13.831 C11.888,12.604 12.884,11.608 14.112,11.608 C15.340,11.608 16.335,12.604 16.335,13.831 C16.335,15.059 15.340,16.055 14.112,16.055 C12.884,16.055 11.888,15.059 11.888,13.831 ZM21.971,13.831 C21.971,12.604 22.968,11.608 24.196,11.608 C25.424,11.608 26.420,12.604 26.420,13.831 C26.420,15.059 25.424,16.055 24.196,16.055 C22.968,16.055 21.971,15.059 21.971,13.831 ZM27.229,22.937 C25.850,26.123 22.623,28.181 19.006,28.181 C15.312,28.181 12.066,26.112 10.735,22.910 C10.507,22.362 10.767,21.733 11.316,21.505 C11.451,21.449 11.591,21.422 11.728,21.422 C12.150,21.422 12.550,21.672 12.722,22.085 C13.718,24.482 16.185,26.030 19.006,26.030 C21.764,26.030 24.216,24.481 25.254,22.083 C25.490,21.537 26.123,21.286 26.668,21.522 C27.213,21.758 27.465,22.391 27.229,22.937 Z'/%3e%3c/svg%3e");
  background-size: cover;
  margin-left: 15px;
`;