import React from 'react';

const DirectChat = () => (
  <div>
    DirectChat
  </div>
);

export default DirectChat;
