import React from 'react';

const Settings = () => (
  <div>
    Settings
  </div>
);

export default Settings;
