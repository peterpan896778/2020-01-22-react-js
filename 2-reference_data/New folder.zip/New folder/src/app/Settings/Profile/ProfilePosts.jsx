import React from 'react';

import ProfileTemplate from './Components/ProfileTemplate';
import Posts from './Components/Posts';

const ProfilePosts = () => (
  <ProfileTemplate>
    <Posts />
  </ProfileTemplate>
);

export default ProfilePosts;
