export { default } from './ProfilePosts';
