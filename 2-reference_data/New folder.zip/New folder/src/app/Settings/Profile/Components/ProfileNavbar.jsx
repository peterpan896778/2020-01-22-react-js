import React, { useContext } from 'react';
import { withRouter } from 'react-router-dom';
import { BlockstackContext } from 'context/BlockstackContext';
import { getUsername } from 'helpers';

const ProfileNavbar = ({ location, history }) => {
  const {
    user
  } = useContext(BlockstackContext);

  const navList = [
    {
      id: 0,
      text: 'Posts',
      location: `/@${getUsername(user)}`,
    },
    {
      id: 1,
      text: 'Favorite',
      location: '/@:username/favorite',
    },
    {
      id: 2,
      text: 'Followers',
      location: '/@:username/followers',
    },
  ];

  return (
    <ul className="feeds-tabs">
      {navList.map((obj) => (

        <li
          key={obj.id}
          className={location.pathname === obj.location ? 'active' : ''}
          onClick={() => history.push(obj.location)}
        >
          {obj.text}
        </li>
      ))}
    </ul>
  );
};

export default withRouter(ProfileNavbar);
