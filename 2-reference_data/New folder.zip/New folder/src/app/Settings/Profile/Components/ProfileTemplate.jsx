import React from 'react';

import ProfileHeader from './ProfileHeader';
import ProfileNavbar from './ProfileNavbar';

import * as S from '../styled';

const ProfileTemplate = ({ children }) => (
  <S.Container>
    <ProfileHeader />
    <div className="profile">
      <ProfileNavbar />
      {children}
    </div>
  </S.Container>
);

export default ProfileTemplate;
