import React from 'react';

const Posts = () => {
  const feeds = [
    {
      id: 0,
      thumbnail: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-img1.png',
      created_at: '9:34 AM',
      description: 'MIT Scientists prove adults learn language to fluency nearly',
      user_avatar: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-user1.png',
      user_name: 'VS Bot'
    },
    {
      id: 1,
      thumbnail: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-img2.png',
      created_at: '9:34 AM',
      description: 'MIT Scientists prove adults learn language to fluency nearly',
      user_avatar: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-user2.png',
      user_name: 'VS Bot'
    },
    {
      id: 2,
      thumbnail: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-img3.png',
      created_at: '9:34 AM',
      description: 'MIT Scientists prove adults learn language to fluency nearly',
      user_avatar: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-user3.png',
      user_name: 'VS Bot'
    },
  ];

  return (
    <div className="feeds">
      {feeds.map((obj) => (
        <div className="feed-block" key={obj.id}>
          <img src={obj.thumbnail} alt="" />
          <div>
            <span>{obj.created_at}</span>
            <p>{obj.description}</p>
            <div>
              <img src={obj.user_avatar} alt="" />
              <p className="feed-avatar">{obj.user_name}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Posts;
