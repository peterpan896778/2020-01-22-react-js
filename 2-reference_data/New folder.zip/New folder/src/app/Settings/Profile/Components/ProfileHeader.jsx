/* eslint-disable jsx-a11y/control-has-associated-label */
/* eslint-disable jsx-a11y/anchor-has-content */
import React from 'react';

const ProfileHeader = () => (
  <div className="profile-header__wrapper">
    <header className="profile-header">
      <button type="button" className="back" name="button" />
      <img src={""} alt="" />
      <div className="profile-header__info">
        <span>Gustavo Zambelli</span>
        <em className="status online" />
        <p>Top #1 on Voicestory</p>
      </div>
      <div className="profile-header__actions">
        <button type="button" className="subscribe-status" name="button" />
        <button type="button" name="button">Message</button>
      </div>
    </header>
    <div className="wallpapper-btns">
      <button type="button" className="add" name="button" />
      <button type="button" className="delete" name="button" />
    </div>
  </div>
);


export default ProfileHeader;
