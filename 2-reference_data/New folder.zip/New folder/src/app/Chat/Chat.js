import React from 'react';

import ChatHeader from './ChatHeader/ChatHeader';
import ChatBody from './ChatBody/ChatBody';
import ChatInput from './ChatInput/ChatInput';
import * as S from './styled';

const Chat = () => (
  <S.Container>
    <ChatHeader />
    <ChatBody />
    <ChatInput />
  </S.Container>
);

export default Chat;
