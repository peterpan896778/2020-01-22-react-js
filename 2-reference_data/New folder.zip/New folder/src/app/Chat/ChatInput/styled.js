import styled from 'styled-components';
import { MentionsInput, Mention } from 'react-mentions'
import DefaultAvatar from 'common/Avatar/Avatar';

export const Container = styled.div`
  width: calc(100% - 60px);
  margin: 32px auto 25px;
  position: relative;
`;

export const InputWrapper = styled.div`
  display: flex;
  align-items: flex-start;
  background: #fff;
  border-radius: 6px;
  border: 1px solid #d4d6da;
  position: relative;
  align-items: center;
  padding: 10px 19px 10px 18px;
`;

export const Input = styled(MentionsInput)`
  width: 100%;
  line-height: 28px;
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 15px;
  color: #111111;
  line-height: 28px;
`;

export const MentionPopup = styled(Mention)`
  background: black;
`;

export const Actions = styled.div`
  display: flex;
  align-items: center;
  position: absolute;
  right: 19px;
  button {
    background-size: cover;
    text-align: left;
    :not(:last-of-type) {
      margin-right: 15px;
    }
  }
`;

export const AttachButton = styled.button.attrs({
  type: 'button',
  ariaLabel: 'Attach'
})`
  margin-right: 15px;
  width: 20px;
  height: 19px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='40px' height='38px'%3e%3cdefs%3e%3cfilter id='Filter_0'%3e%3cfeFlood flood-color='rgb(134, 134, 134);
`;

export const EmojiButton = styled.button.attrs({
  type: 'button',
  ariaLabel: 'Emoji'
})`
  width: 20px;
  height: 20px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='38px' height='38px'%3e%3cpath fill-rule='evenodd' fill='rgb(134, 134, 134);
`;

export const SendButton = styled.button.attrs({
  type: 'button',
  ariaLabel: 'Attach'
})`
  width: 18px;
  height: 16px;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='37' height='33'%3E%3Cpath fill-rule='evenodd' fill='%23868686' d='M34.788 13.691L4.952 1.266a3.54 3.54 0 00-3.706.6A3.573 3.573 0 00.123 5.461l2.656 10.452h13.002c.598 0 1.084.487 1.084 1.087 0 .601-.485 1.088-1.084 1.088H2.779L.123 28.54a3.573 3.573 0 001.123 3.595 3.542 3.542 0 003.706.6l29.836-12.424c1.358-.566 2.202-1.834 2.202-3.311 0-1.476-.844-2.744-2.202-3.309z'/%3E%3C/svg%3E");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  :hover {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='37' height='33'%3E%3Cpath fill-rule='evenodd' fill='%23131313' d='M34.788 13.691L4.952 1.266a3.54 3.54 0 00-3.706.6A3.573 3.573 0 00.123 5.461l2.656 10.452h13.002c.598 0 1.084.487 1.084 1.087 0 .601-.485 1.088-1.084 1.088H2.779L.123 28.54a3.573 3.573 0 001.123 3.595 3.542 3.542 0 003.706.6l29.836-12.424c1.358-.566 2.202-1.834 2.202-3.311 0-1.476-.844-2.744-2.202-3.309z'/%3E%3C/svg%3E")
  }
`;

export const GuestBlock = styled.div`
  width: 100%;
`;

export const Paragraph = styled.div`
  width: 100%;
`;

export const Button = styled.button.attrs({
  type: 'button',
})`
  width: 100%;
`;

export const MentionInputStyles = {
  suggestions: {
    list: {
      width: 348,
      background: '#fff',
      borderRadius: 6,
      border: '1px solid #e2e2e2',
      boxShadow: '0 20px 60px 0 rgba(6, 6, 37, 0.06)',
      paddingTop: 12,
      paddingBottom: 16,
      transition: 'opacity 0.2s ease-in-out',
    },
    item: {
      '&focused': {
        backgroundColor: '#ece6f5'
      },
    }
  },
};

export const MentionStyles = {
  backgroundColor: '#e8f5fa',
  color: '#2670aa',
  padding: '4px 0'
};


export const ListItem = styled.li`
  width: 100%;
  height: 28px;
  display: flex;
  align-items: center;
  white-space: nowrap;
  font-size: 15px;
  padding: 0 24px;
  overflow: hidden;
  cursor: pointer;
  margin-top: 4px;
  :hover {
    background: #212464;
    color: #fff;
  }
  &--focused {
    background: #212464;
    color: #fff;
  }
`;

export const Avatar = styled(DefaultAvatar).attrs({
  alt: 'Avatar'
})`
  width: 20px;
  height: 20px;
  border-radius: 5px;
  overflow: hidden;
`;

export const Fullname = styled.p`
  max-width: 135px;
  font-family: "Helvetica Neue Cyr Medium";
  color: #1d1c1d;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-left: 11px;
  margin-bottom: -1px;
  ${ListItem}:hover & {
    color: white;
  }
`;

export const Username = styled.span`
  max-width: 100px;
  font-family: "Helvetica Neue Cyr Roman";
  color: #616061;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-left: 5px;
  ${ListItem}:hover & {
    color: #b6b8e7;
  }
`;

export const Status = styled.em`
  display: inline-block;
  width: 6px;
  height: 6px;
  border: 2px solid #616061;
  border-radius: 50%;
  margin-left: 10px;
  box-sizing: content-box;
  ${ListItem}:hover & {
    border-color: white;
  }
  ${props => props.online && `
    width: 10px;
    height: 10px;
    background: #007a5a;
    border: none;
    ${ListItem}:hover & {
      background: #34c19c;
    }
  `}
`;
