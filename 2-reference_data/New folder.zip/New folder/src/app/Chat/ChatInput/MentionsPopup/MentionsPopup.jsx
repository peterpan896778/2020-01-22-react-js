import React from 'react';

const users = [
  {
    nickname: '@glebich',
    fullname: 'Gleb Kuznetsov',
    image: 'http://mish-sanek.online/v5_helvetica/img/chat-img/small-user2.png'
  },
  {
    nickname: '@themce',
    fullname: 'Maciej Kałaska',
    image: 'http://mish-sanek.online/v5_helvetica/img/chat-img/small-user4.png'
  },
  {
    nickname: '@lobanovskiy',
    fullname: 'Eddie Lobanovskiy',
    image: 'http://mish-sanek.online/v5_helvetica/img/chat-img/small-user3.png'
  },
  {
    nickname: '@leonardo_art',
    fullname: 'Fireart Studio',
    image: 'http://mish-sanek.online/v5_helvetica/img/chat-img/small-user1.png'
  }
];

const MentionsPopup = ({ username: searchString }) => {
  return (
    <div className="chat-input__users-popup visible">
      <p>Users</p>
      <ul>
        {users.map(user => (
          user.nickname.indexOf(searchString) > -1 ||
          user.fullname.indexOf(searchString) > -1
        ) &&
          <li key={user.fullname}>
            <img src={user.image} alt="Avatar" />
            <p>{user.fullname}</p>
            <span>{user.nickname}</span>
            <em className="status online" />
          </li>
        )}
      </ul>
    </div>
  );
};

export default MentionsPopup;
