import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useMutation } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';
import { Mention } from 'react-mentions';

import submitSound from 'assets/sounds/submit.wav';
import * as S from './styled';

const SubmitSound = new Audio(submitSound);

// import { Picker } from 'emoji-mart';
// import { emojiNames } from '../../../../src/helpers/emojis';

const SEND_MESSAGE = gql`
  mutation sendMessage(
    $body: String!,
    $channelUrl: String!,
  ) {
    sendMessage(
      body: $body,
      channelUrl: $channelUrl,
    ) {
      id
      body
      createdAt
      author {
        id
        username
      }
    }
  }
`;

const SEND_NOTIFICATION = gql`
  mutation sendNotification(
    $sentToUser: String!,
    $messageId: ID!,
  ) {
    sendNotification(
      sentToUser: $sentToUser,
      messageId: $messageId,
      type: "mention",
    ) {
      id
    }
  }
`;

const GET_USERS = gql`
  mutation users($searchString: String) {
    users(searchString: $searchString) {
      id
      username
    }
  }
`;

const ChatInput = ({ isAuthorized = true }) => {
  const [body, setBody] = useState('');
  const [mentions, setMentions] = useState([]);

  const [sendMessage] = useMutation(SEND_MESSAGE);
  const [sendNotification] = useMutation(SEND_NOTIFICATION);
  const [getUsers] = useMutation(GET_USERS);

  const { communityUrl, channelUrl } = useParams();

  const onSendMessage = async () => {
    setBody('');
    SubmitSound.play();
    const { data: { sendMessage: { id } } } = await sendMessage({
      variables: {
        body, channelUrl: `${communityUrl}/${channelUrl}`
      }
    });
    if (mentions) {
      mentions.map(mention => sendNotification({
        variables: {
          messageId: id,
          sentToUser: mention.id
        }
      }));
      setMentions([]);
    }
  };

  const onKeyDown = e => {
    // Sending message
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage();
    }
  };

  return (
    <S.Container>
      {isAuthorized ?
        <S.InputWrapper>
          <S.Input
            placeholder="Send a message"
            type="text"
            value={body}
            onChange={(event, a, b, newMentions) => {
              setBody(event.target.value);
              setMentions(newMentions);
            }}
            onKeyDown={(e) => onKeyDown(e)}
            style={S.MentionInputStyles}
            allowSuggestionsAboveCursor
          >
            <Mention
              trigger="@"
              displayTransform={username => `@${username}`}
              data={async (searchString, callback) => {
                const { data: { users = [] } = {} } = await getUsers({
                  variables: { searchString }
                });
                callback(users.map(user => ({
                  id: user.username,
                  display: user.username
                })));
              }}
              className="suggestions"
              style={S.MentionStyles}
              appendSpaceOnAdd
              renderSuggestion={user => (
                <S.ListItem>
                  <S.Avatar src={user.image} name={user.display} />
                  <S.Fullname>{user.display}</S.Fullname>
                  <S.Username>{`@${user.display}`}</S.Username>
                  <S.Status online />
                </S.ListItem>
              )}
            />
          </S.Input>
          <S.Actions>
            {/*
            <S.AttachButton />
            <label htmlFor="comment-image" className="chat-input__image">
              <input
                type="file"
                id="comment-image"
                accept="image/*"
                onChange={() => {}}
              />
            </label>
            <S.EmojiButton
              className="chat-input__emoji"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            >
              <Picker
                onSelect={() => {}}
                style={{ display: showEmojiPicker ? 'block' : 'none' }}
                emojisToShowFilter={emoji => emojiNames.indexOf(emoji.name) > -1}
              />
            </S.EmojiButton>
            */}
            {(body !== '') &&
              <S.SendButton onClick={() => onSendMessage} />
            }
          </S.Actions>
        </S.InputWrapper>
        :
        <S.GuestBlock>
          <S.Paragraph>
            Sign In to start chatting!
          </S.Paragraph>
          <S.Button onClick={() => {}}>
            Log In
          </S.Button>
          <S.Button onClick={() => {}}>
            Sign Up
          </S.Button>
        </S.GuestBlock>
      }
    </S.Container>
  );
};

export default ChatInput;
