import React from 'react';
import ContentLoader from 'react-content-loader';

import * as S from './styled';

const ChatBodyPlaceholder = () => (
  <S.Container>
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
    <MessagePlaceholder />
  </S.Container>
);

const MessagePlaceholder = () => (
  <ContentLoader
    height={53}
    width={700}
    style={{ width: 700, height: 53 }}
    speed={1}
    primaryColor="#eeeeee"
    secondaryColor="#f0f0f0"
  >
    <rect x="0" y="7" rx="6" ry="6" width="36" height="36" />
    <rect x="50" y="7" rx="4" ry="4" width="169" height="14" />
    <rect x="50" y="25" rx="4" ry="4" width="319" height="14" />
  </ContentLoader>
);

export const ChatBodyEmpty = () => (
  <S.ChatEmptyContainer>
    <S.ChatEmptyImage />
    <S.ChatEmptyHeading>
      No one’s around to play with Wumpus.
    </S.ChatEmptyHeading>
    <S.ChatEmptyParagraph>
      You can write a message to your friend
    </S.ChatEmptyParagraph>
  </S.ChatEmptyContainer>
);

export default ChatBodyPlaceholder;
