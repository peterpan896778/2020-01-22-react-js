import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';
import { groupBy } from 'lodash';
import moment from 'moment';

import Message from 'common/Message/Message';
import ChatBodyPlaceholder, { ChatBodyEmpty } from './ChatBodyPlaceholder';
import * as S from './styled';

export const GET_MESSAGES = gql`
  query messages($channelUrl: String) {
    messages(channelUrl: $channelUrl) {
      id
      body
      createdAt
      author {
        id
        username
      }
    }
  }
`;

export const MESSAGES_SUBSCRIPTION = gql`
  subscription newMessage($channelUrl: String) {
    newMessage(channelUrl: $channelUrl) {
      id
      body
      createdAt
      author {
        id
        username
      }
    }
  }
`;

const ChatBody = () => {
  const { communityUrl, channelUrl } = useParams();
  const { data: { messages } = {}, loading, subscribeToMore } = useQuery(GET_MESSAGES, {
    variables: { channelUrl: `${communityUrl}/${channelUrl}` }
  });

  useEffect(() =>
    subscribeToMore({
      document: MESSAGES_SUBSCRIPTION,
      variables: { channelUrl: `${communityUrl}/${channelUrl}` },
      updateQuery: (prev, { subscriptionData }) => {
        if (!subscriptionData.data) return prev;
        const { newMessage } = subscriptionData.data;

        return {
          ...prev,
          messages: [...prev.messages, newMessage]
        };
      }
    }), [communityUrl, channelUrl]);

  useEffect(() => {
    const chat = document.getElementsByClassName('chat')[0];
    if (chat) {
      chat.scrollTop = chat.scrollHeight;
    }
  }, [messages]);

  if (loading) {
    return (
      <ChatBodyPlaceholder />
    );
  }

  if (messages.length === 0) {
    return (
      <ChatBodyEmpty />
    );
  }

  const messagesByDay = groupBy(messages, date => moment(date).startOf('day').format());

  return (
    <S.Container className="chat">
      {Object.entries(messagesByDay).map(([date, messagesList]) =>
        <React.Fragment key={date}>
          <S.Date>
            <S.DateText>
              {moment(date).format('dddd, MMMM Do')}
            </S.DateText>
          </S.Date>
          {messagesList.map((message, index, list) => {
            const previousMessage = list[index - 1];
            const isChild = (
              previousMessage &&
              previousMessage.author.username === message.author.username
            );

            const unreadCount = 2;

            return (
              <>
                {index === unreadCount &&
                  <S.NewMessage>
                    <S.NewMessageText>
                      new messages
                    </S.NewMessageText>
                  </S.NewMessage>
                }
                <Message
                  key={message.id}
                  message={message}
                  isChild={isChild}
                />
              </>
            );
          })}
        </React.Fragment>
      )}
    </S.Container>
  );
};

export default ChatBody;
