import styled from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';
import chatEmpty from 'assets/images/illustrations/empty-chat.png';

// eslint-disable-next-line import/prefer-default-export
export const Container = styled(PerfectScrollbar)`
  height: 100%;
  width: 100%;
  padding: 28px 30px 0;
  position: relative;
`;

export const Date = styled.div`
  text-align: center;
  margin-top: 2px;
  position: relative;
  :before {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background: #e8e8e8;
    position: absolute;
    left: 0;
    top: 10px;
    z-index: -1;
  }
`;

export const DateText = styled.span`
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 13px;
  color: #1d1c1d;
  background: #fff;
  padding: 0 12px;
  text-align: center;
`;

export const NewMessage = styled.div`
  text-align: center;
  margin-top: 2px;
  position: relative;
  :before {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background: #f19393;
    position: absolute;
    left: 0;
    top: 10px;
    z-index: -1;
  }
`;

export const NewMessageText = styled.span`
  display: inline-block;
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 11px;
  color: #dd3030;
  line-height: 17px;
  background: #fff;
  padding: 0 7px;
`;

export const ChatEmptyContainer = styled.div`
  height: 100%;
  width: 748px;
  padding: 0 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const ChatEmptyImage = styled.img.attrs({
  alt: 'Empty',
  src: chatEmpty
})`
  width: 500px;
  margin-top: 85px;
`;

export const ChatEmptyHeading = styled.h1`
  font-family: Helvetica Neue Cyr Bold;
  font-size: 15px;
  color: #1d1c1d;
  margin-top: 70px;
`;

export const ChatEmptyParagraph = styled.p`
  font-family: Helvetica Neue Cyr Roman;
  font-size: 14px;
  color: #868686;
  margin-top: 12px;
`;
