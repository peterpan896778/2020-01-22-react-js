import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';

import ChatHeaderPlaceholder from './ChatHeaderPlaceholder';
import * as S from './styled';

export const GET_CHANNEL = gql`
  query channel($uniqueUrl: String) {
    channel(uniqueUrl: $uniqueUrl) {
      id
      name
      url
      description
      members {
        id
      }
    }
  }
`;

const ChatHeader = () => {
  const { communityUrl, channelUrl } = useParams();
  const { data: { channel = { members: [] } } = {}, loading } = useQuery(GET_CHANNEL, {
    variables: { uniqueUrl: `${communityUrl}/${channelUrl}` }
  });

  if (loading) {
    return (
      <ChatHeaderPlaceholder />
    );
  }

  return (
    <S.Container>
      <S.ChatInfo>
        <S.ChatName>
          {`# ${channel.name}`}
        </S.ChatName>
        <S.ChatInfoBottom>
          <S.UsersCount>
            {channel.members.length}
          </S.UsersCount>
          {channel.description &&
            <S.ChatTopic>
              {channel.description}
            </S.ChatTopic>
          }
        </S.ChatInfoBottom>
      </S.ChatInfo>
      <S.ChatActions>
        <S.SearchIcon />
        <S.MoreIcon />
      </S.ChatActions>
    </S.Container>
  );
};

export default ChatHeader;
