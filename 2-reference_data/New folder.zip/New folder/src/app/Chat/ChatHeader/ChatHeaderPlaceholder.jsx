import React from 'react';
import ContentLoader from 'react-content-loader';

import { Container } from './styled';

const ChatHeaderPlaceholder = () => (
  <Container>
    <ContentLoader
      height={61}
      width={400}
      style={{ width: 400, height: 61 }}
      speed={1}
      primaryColor="#eeeeee"
      secondaryColor="#f0f0f0"
    >
      <rect x="0" y="12.5" rx="4" ry="4" width="109" height="16" />
      <rect x="0" y="34" rx="4" ry="4" width="219" height="14" />
    </ContentLoader>
  </Container>
);

export default ChatHeaderPlaceholder;
