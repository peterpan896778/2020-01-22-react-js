import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  height: 61px;
  min-height: 61px;
  border-bottom: 1px solid #e8e8e8;
  padding: 0 30px;
  width: 100%;
  background: white;
`;

export const ChatInfo = styled.div`

`;

export const ChatInfoBottom = styled.div`
  display: flex;
  align-items: center;
  font-family: Helvetica Neue Cyr Roman;
  font-size: 14px;
  color: #939393;
`;

export const ChatName = styled.span`
  display: block;
  font-family: Helvetica Neue Cyr Bold;
  font-size: 16px;
  color: #111;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  line-height: 16px;
`;

export const UsersCount = styled.p`
  height: 13px;
  font-family: Helvetica Neue Cyr Roman;
  font-size: 14px;
  color: #939393;
  :before {
    content: "";
    display: inline-block;
    width: 10px;
    height: 11px;
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='22'%3E%3Cpath fill-rule='evenodd' fill='%23939393' d='M19.886 16.46a8.81 8.81 0 01-.684.997c-.355.473-.761.897-1.166 1.296-.355.349-.761.698-1.166.997a11.609 11.609 0 01-6.894 2.244c-2.484 0-4.891-.773-6.893-2.244-.406-.324-.812-.648-1.166-.997a9.578 9.578 0 01-1.166-1.296 9.806 9.806 0 01-.684-.997c-.076-.15-.102-.324-.026-.474.152-.349.355-.723.583-1.047a7.176 7.176 0 014.993-3.091.961.961 0 01.735.174 6.172 6.172 0 003.649 1.172 6.171 6.171 0 003.65-1.172c.203-.15.482-.199.735-.174a7.228 7.228 0 014.993 3.091c.228.324.431.673.583 1.047.076.15.05.324-.076.474zm-9.885-5.036c-3.193 0-5.803-2.568-5.803-5.709 0-3.141 2.61-5.709 5.803-5.709 3.194 0 5.804 2.568 5.804 5.709 0 3.141-2.61 5.709-5.804 5.709z'/%3E%3C/svg%3E");
    background-size: cover;
    margin-right: 7px;
    margin-bottom: -1px;
  }
`;

export const ChatTopic = styled.div`
  margin-left: 9px;
  max-width: 500px;
  word-break: break-word;
  text-align: left;
  :before {
    content: "";
    display: inline-block;
    width: 1px;
    height: 10px;
    background: #cacaca;
    margin-right: 8px;
  }
`;

export const ChatActions = styled.div`

`;

export const SearchIcon = styled.div`

`;

export const MoreIcon = styled.div`

`;
