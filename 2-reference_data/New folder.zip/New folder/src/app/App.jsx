import React, { useContext } from 'react';
import {
  BrowserRouter as Router,
  Route as PublicRoute,
  Switch,
  Redirect,
} from 'react-router-dom';

import BlockstackProvider, { BlockstackContext } from 'context/BlockstackContext';
import ApolloProvider from 'context/ApolloContext';

import RightBar from './RightBar/RightBar';
import Login from './Login/Login';
import Navbar from './Navbar/Navbar';
import Communities from './Communities/Communities';
import CommunitiesBar from './Communities/CommunitiesBar/CommunitiesBar';
import CommunityCreate from './Communities/CommunityCreate';
import Chat from './Chat/Chat';
import Directs from './Directs/Directs';
import DirectChat from './Directs/DirectChat/DirectChat';
import Help from './Help/Help';
import Settings from './Settings/Settings';
import Profile from './Settings/Profile/index';
// import Feed from './Feed/Feed';
// import Post from './Feed/Post/Post';
// import PostCreate from './Feed/PostCreate/PostCreate';
import Campaigns from './Campaigns/Campaigns';
import CampaignCreate from './Campaigns/CampaignCreate';
import ChannelCreate from './Channels/ChannelCreate';
import Editor from './Editor/Editor';

import * as S from './styled';

const Providers = ({ children }) => (
  <ApolloProvider>
    <BlockstackProvider>
      {children}
    </BlockstackProvider>
  </ApolloProvider>
);

/* eslint-disable react/jsx-props-no-spreading, no-nested-ternary */
const LoginRoute = ({ children, ...rest }) => {
  const { BlockStackSession } = useContext(BlockstackContext);
  const isLogged = BlockStackSession.isUserSignedIn();

  return (
    <PublicRoute
      {...rest}
      render={({ location }) => isLogged ?
        <Redirect to="/voicestory/general" /> :
        /\?authResponse=/.test(location.search) ?
          <Login /> :
          <Redirect
            to={{
              pathname: '/login',
              state: { from: location }
            }}
          />
      }
    />
  );
};

const Route = ({ children, ...rest }) => {
  const { BlockStackSession } = useContext(BlockstackContext);
  const isLogged = BlockStackSession.isUserSignedIn();

  return (
    <PublicRoute
      {...rest}
      render={({ location }) =>
        (isLogged || /\?authResponse=/.test(location.search))
          ? children
          : <Redirect
            to={{
              pathname: '/login',
              state: { from: location }
            }}
          />
      }
    />
  );
};

const RouteWithLayout = ({ children, withoutRightBar, ...rest }) =>
  <Route {...rest}>
    <S.Layout>
      <Navbar />
      <CommunitiesBar />
      {children}
      {!withoutRightBar &&
        <RightBar />
      }
    </S.Layout>
  </Route>;

const App = () => (
  <Providers>
    <Router>
      <Switch>

        {/* Root */}
        <PublicRoute path="/">
          <Editor />
        </PublicRoute>
       
      </Switch>
    </Router>
  </Providers>
);

export default App;
