import React from 'react';

const Campaigns = () => (
  <div>
    Campaigns
  </div>
);

export default Campaigns;
