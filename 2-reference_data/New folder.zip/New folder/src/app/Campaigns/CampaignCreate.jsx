import React from 'react';

const CampaignCreate = () => (
  <div>
    CampaignCreate
  </div>
);

export default CampaignCreate;
