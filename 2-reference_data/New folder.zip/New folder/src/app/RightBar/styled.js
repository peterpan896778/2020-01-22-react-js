import styled from 'styled-components';

// eslint-disable-next-line import/prefer-default-export
export const Container = styled.div`
  width: 325px;
  min-width: 325px;
  height: 100vh;
  background: #fff;
  border-left: 1px solid #e7e7e7;
  z-index: 2;
`;
