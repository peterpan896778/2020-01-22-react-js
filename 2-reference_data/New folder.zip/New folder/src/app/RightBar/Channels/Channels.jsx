import React from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';

import ChannelsPlaceholder from './ChannelsPlaceholder';
import * as S from './styled';

export const GET_CHANNELS = gql`
  query channels($communityUrl: String!) {
    channels(communityUrl: $communityUrl) {
      id
      name
      url
    }
  }
`;

const ChannelsComponent = () => {
  const { communityUrl, channelUrl } = useParams();
  const history = useHistory();
  const { data: { channels = [] } = {}, loading } = useQuery(GET_CHANNELS, {
    variables: { communityUrl }
  });

  if (loading) {
    return (
      <ChannelsPlaceholder />
    );
  }

  return (
    <S.Container>
      <S.Header>
        <S.HeaderTitle>
          Channels
        </S.HeaderTitle>
      </S.Header>
      <S.List>
        {channels.map(channel => (
          <S.ListItem
            key={channel.id}
            unread
            active={channel.url === channelUrl}
            onClick={() => history.push(`/${communityUrl}/${channel.url}`)}
          >
            {channel.name}
          </S.ListItem>
        ))}
      </S.List>
    </S.Container>
  );
};

export default ChannelsComponent;
