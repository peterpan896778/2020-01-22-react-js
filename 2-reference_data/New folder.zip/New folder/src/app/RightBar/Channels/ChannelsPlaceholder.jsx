import React from 'react';
import ContentLoader from 'react-content-loader';

const ChannelsPlaceholder = () => (
  <ContentLoader
    height={157}
    width={325}
    speed={1}
    primaryColor="#eeeeee"
    secondaryColor="#f0f0f0"
  >
    <rect x="16" y="30" rx="4" ry="4" width="109" height="19" />
    <rect x="16" y="74" rx="4" ry="4" width="293" height="21" />
    <rect x="16" y="105" rx="4" ry="4" width="293" height="21" />
    <rect x="16" y="136" rx="4" ry="4" width="293" height="21" />
  </ContentLoader>
);

export default ChannelsPlaceholder;
