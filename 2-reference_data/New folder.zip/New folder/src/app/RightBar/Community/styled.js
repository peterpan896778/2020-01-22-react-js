import styled from 'styled-components';
import arrow from 'icons/arrow.svg';
import arrowAfter from 'icons/arrow-after.svg';

export const Container = styled.div`
`;

export const Header = styled.header`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding: 0 16px;
  position: relative;
  margin-top: 16px;
`;

export const Heading = styled.h2`
  width: 100%;
  display: flex;
  align-items: center;
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 17px;
  color: #111111;
  margin-right: auto;
  position: relative;
  z-index: 1;
  cursor: pointer;
`;

export const Image = styled.img.attrs({
  alt: 'Logo'
})`
  width: 21px;
  height: 21px;
  border-radius: 4px;
  margin-right: 10px;
  margin-top: -3px;
  overflow: hidden;
`;

export const Name = styled.button.attrs({
  type: 'button'
})`
  display: flex;
  align-items: center;
  :active {
    span:before {
      transform: scale(1);
    }
  }
`;

export const Arrow = styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 31px;
  height: 31px;
  border-radius: 50%;
  position: relative;
  margin-left: 7px;
  :before {
    content: "";
    display: block;
    width: 31px;
    height: 31px;
    background: #d4d4d4;
    border-radius: 50%;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 0;
    transform: scale(0);
    transition: transform 0.05s ease-in-out;
  }
  :after {
    content: "";
    display: inline-block;
    width: 13px;
    height: 8px;
    background-image: url(${arrow});
    background-size: cover;
    z-index: 1;
    transition: -webkit-transform 0.05s ease-in-out;
    transition: transform 0.05s ease-in-out;
    ${props => props.opened && `
      transform: rotateX(180deg);
    `}
  }
  :hover {
    :after {
      background-image: url(${arrowAfter});
    }
  }
`;

export const Popup = styled.div`
  width: 292px;
  background: #fff;
  -webkit-box-shadow: 0 0 0 1px rgba(29,28,29, 0.13), 0 4px 12px 0 rgba(0,0,0,.08);
  box-shadow: 0 0 0 1px rgba(29,28,29, 0.13), 0 4px 12px 0 rgba(0,0,0,.08);
  visibility: hidden;
  opacity: 0;
  border-radius: 6px;
  position: absolute;
  right: 9px !important;
  top: 44px !important;
  z-index: -1;
  -webkit-transition: opacity 0.2s ease-in-out;
  -o-transition: opacity 0.2s ease-in-out;
  transition: opacity 0.2s ease-in-out;
  ${props => props.show && `
    visibility: visible;
    opacity: 1;
    z-index: 1;
  `}
`;

export const PopupCommunityInfo = styled.div`
  display: flex;
  align-items: center;
  padding: 16px 20px;
`;

export const PopupImage = styled.img.attrs({
  alt: 'Logo'
})`
  width: 36px;
  height: 36px;
  border-radius: 6px;
  margin-right: 15px;
  overflow: hidden;
`;

export const PopupName = styled.p`
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 15px;
  color: #1d1c1d;
  margin-bottom: 4px;
`;

export const PopupUrl = styled.span`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 15px;
  color: #606060;
`;

export const PopupList = styled.ul`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 15px;
  color: #131313;
  border-top: 1px solid #e8e8e8;
  border-bottom: 1px solid #e8e8e8;
  padding: 12px 9px;
  margin-top: 0 !important;
`;

export const PopupListItem = styled.li`
  max-width: calc(100% - 16px);
  height: 31px;
  display: flex;
  align-items: center;
  line-height: 32px;
  white-space: nowrap;
  padding-left: 8px;
  padding-right: 8px;
  border-radius: 5px;
  cursor: pointer;
  position: relative;
  :hover {
    background: #ece6f5;
  }
  :active {
    background: #212464;
    color: #fff;
  }
`;
