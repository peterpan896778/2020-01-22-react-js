import React from 'react';
import ContentLoader from 'react-content-loader';

const CommunityPlaceholder = () => (
  <ContentLoader
    height={47}
    width={325}
    speed={1}
    primaryColor="#eeeeee"
    secondaryColor="#f0f0f0"
  >
    <rect x="16" y="21" rx="4" ry="4" width="21" height="21" />
    <rect x="47" y="22" rx="4" ry="4" width="180" height="19" />
  </ContentLoader>
);

export default CommunityPlaceholder;
