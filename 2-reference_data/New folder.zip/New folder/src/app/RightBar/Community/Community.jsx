import React, { useState } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';

import CommunityPlaceholder from './CommunityPlaceholder';
import * as S from './styled';

export const GET_COMMUNITY = gql`
  query community($url: String) {
    community(url: $url) {
      id
      name
      url
      description
      image
    }
  }
`;

const Community = () => {
  const [showCommunityPopup, setShowCommunityPopup] = useState(false);
  const { communityUrl } = useParams();
  const history = useHistory();
  const { data: { community = {} } = {}, loading } = useQuery(GET_COMMUNITY, {
    variables: { url: communityUrl }
  });

  if (loading) {
    return (
      <CommunityPlaceholder />
    );
  }

  return (
    <S.Header onClick={() => setShowCommunityPopup(!showCommunityPopup)}>
      <S.Heading>
        <S.Image src={community.image} />
        <S.Name>
          {community.name}
          <S.Arrow opened={showCommunityPopup} />
        </S.Name>
      </S.Heading>
      <S.Popup
        className="info-community"
        show={showCommunityPopup}
      >
        <S.PopupCommunityInfo>
          <S.PopupImage src={community.image} />
          <div>
            <S.PopupName>
              {community.name}
            </S.PopupName>
            <S.PopupUrl>
              {`${community.url}.voicestory.com`}
            </S.PopupUrl>
          </div>
        </S.PopupCommunityInfo>
        <S.PopupList>
          <S.PopupListItem onClick={() => history.push(`/${community.url}/new-channel`)}>
            New channel
          </S.PopupListItem>
        </S.PopupList>
      </S.Popup>
    </S.Header>
  );
};

export default Community;
