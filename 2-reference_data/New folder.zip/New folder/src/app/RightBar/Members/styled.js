import styled from 'styled-components';

import DefaultAvatar from 'common/Avatar/Avatar';

export const Container = styled.div`
  position: relative;
`;

export const Header = styled.header`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding: 0 16px;
  margin-top: 30px;
`;

export const HeaderTitle = styled.p`
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 17px;
  color: #111111;
  margin-right: auto;
`;

export const List = styled.ul`
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 15px;
  color: #1d1c1d;
  padding: 0 9px;
  margin-top: 20px;
`;

export const ListItem = styled.li`
  position: relative;
  max-width: calc(100% - 16px);
  height: 31px;
  display: flex;
  align-items: center;
  line-height: 32px;
  white-space: nowrap;
  padding: 0 8px;
  border-radius: 5px;
  cursor: pointer;
  color: #616061;
  user-select: none;
  ${props => props.unread && `
    color: #1d1c1d;
  `}
  :hover {
    background: #ece6f5;
  }
  :active {
    background: #212464;
    color: #fff;
  }
  ${props => props.active && `
    background: #34378b;
    color: #fff;
    :hover {
      background: #34378b;
      color: #fff;
    }
  `}
`;

export const Avatar = styled(DefaultAvatar).attrs({
  alt: 'Avatar'
})`
  width: 25px;
  height: 25px;
  border-radius: 5px;
  margin-right: 10px;
`;

export const Name = styled.span`
  max-width: calc(100% - 75px);
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  margin-bottom: -2px;
  color: #1d1c1d;
`;

export const Status = styled.i`
  display: inline-block;
  width: 6px;
  height: 6px;
  border: 2px solid #616061;
  border-radius: 50%;
  margin-left: 10px;
  box-sizing: content-box;
  ${ListItem}:hover & {
    border-color: white;
  }
  ${props => props.online && `
    width: 10px;
    height: 10px;
    background: #007a5a;
    border: none;
    ${ListItem}:hover & {
      background: #34c19c;
    }
  `}
`;
