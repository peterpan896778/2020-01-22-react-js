import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';
import { getUsername } from 'helpers';

import MembersPlaceholder from './MembersPlaceholder';
import * as S from './styled';

export const GET_CHANNEL_MEMBERS = gql`
  query channel($uniqueUrl: String) {
    channel(uniqueUrl: $uniqueUrl) {
      members {
        id
        username
        isOnline
      }
    }
  }
`;

export const USER_WENT_ONLINE = gql`
  subscription userWentOnline($channelUrl: String) {
    userWentOnline(channelUrl: $channelUrl) {
      user {
        id
        username
        isOnline
      }
    }
  }
`;

export const USER_WENT_OFFLINE = gql`
  subscription userWentOffline($channelUrl: String) {
    userWentOffline(channelUrl: $channelUrl) {
      user {
        id
        username
        isOnline
      }
    }
  }
`;

const Members = () => {
  const { communityUrl, channelUrl } = useParams();
  const {
    data: { channel: { members } = {} } = {},
    loading,
    subscribeToMore
  } = useQuery(GET_CHANNEL_MEMBERS, {
    variables: { uniqueUrl: `${communityUrl}/${channelUrl}` }
  });

  useEffect(() => {
    subscribeToMore({
      document: USER_WENT_ONLINE,
      variables: { channelUrl: `${communityUrl}/${channelUrl}` },
    });
    subscribeToMore({
      document: USER_WENT_OFFLINE,
      variables: { channelUrl: `${communityUrl}/${channelUrl}` },
    });
  }, []);

  // TODO: not sure about this behavior
  if (loading || !members) {
    return (
      <MembersPlaceholder />
    );
  }

  return (
    <S.Container>
      <S.Header>
        <S.HeaderTitle>
          {`${members.length} members`}
        </S.HeaderTitle>
      </S.Header>
      <S.List>
        {members.map(member =>
          <S.ListItem key={member.id}>
            <S.Avatar src={member.image} name={getUsername(member)} />
            <S.Name>
              {member.username}
            </S.Name>
            <S.Status online={member.isOnline} />
          </S.ListItem>
        )}
      </S.List>
    </S.Container>
  );
};

export default Members;
