import React from 'react';

import Community from './Community/Community';
import Channels from './Channels/Channels';
import Members from './Members/Members';

import * as S from './styled';

const RightBar = () => (
  <S.Container>
    <Community />
    <Channels />
    <Members />
  </S.Container>
);

export default RightBar;
