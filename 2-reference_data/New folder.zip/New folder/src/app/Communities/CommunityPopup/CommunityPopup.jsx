import React from 'react';
import { useQuery, useMutation } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';

import * as S from './styled';

export const GET_COMMUNITY = gql`
  query community($id: ID) {
    community(id: $id) {
      id
      name
      description
      image
      followers {
        id
      }
      channels {
        id
      }
    }
  }
`;

export const UNFOLLOW_COMMUNITY = gql`
  mutation unfollowCommunity($url: String) {
    unfollowCommunity(url: $url) {
      id
      followers {
        id
      }
    }
  }
`;

const CommunityPopup = ({ id }) => {
  const { data: { community } = {}, loading } = useQuery(GET_COMMUNITY, {
    variables: { id }
  });
  const [unfollowCommunity] = useMutation(UNFOLLOW_COMMUNITY);

  if (loading) {
    return (
      <div className="left-channels__popup">loading...</div>
    );
  }

  return (
    <div className="left-channels__popup">
      <header>
        <S.Image src={community.image} />
        <S.Name>
          {community.name}
        </S.Name>
      </header>
      <div className="channel-info">
        <div>
          <span>Followers</span>
          <p>{community.followers.length}</p>
        </div>
        <div>
          <span>Channels</span>
          <p>{community.channels.length}</p>
        </div>
        <div>
          <span>Posts</span>
          <p>0</p>
        </div>
      </div>
      {community.description &&
        <div className="channel-description">
          <p>Description</p>
          <span>
            {community.description}
          </span>
        </div>
      }
      <div className="actions">
        <S.UnfollowButton onClick={() =>
          unfollowCommunity({ variables: { url: community.url } })}
        />
        {/*
        <button type="button" name="button">Switch</button>
        <button type="button" className="actions__more-btn" name="button"></button>
        */}
      </div>
    </div>
  );
};

export default CommunityPopup;
