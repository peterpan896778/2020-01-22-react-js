import styled from 'styled-components';

export const Container = styled.div`
  justify-content: center;
  width: 100%;
  padding: 0;
`;

export const Image = styled.img.attrs({
  alt: 'Community logo'
})`
  width: 36px;
  height: 36px;
  border-radius: 3px;
  overflow: hidden;
  margin-right: 14;
  object-fit: cover;
  object-position: center;
`;

export const Name = styled.div`
  max-width: calc(100% - 50px);
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  margin-bottom: -1px;
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 22px;
  color: #1d1c1d;
`;

export const UnfollowButton = styled.button.attrs({
  type: 'button',
  ariaLabel: 'Unsubscribe',
})`
  height: 36px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 15px;
  color: #1d1c1d;
  line-height: 37px;
  border-radius: 5px;
  padding: 0 19px;
  background: #43b581;
  border-color: #43b581;
  :before {
    content: "Following";
    color: #fff;
  }
  :hover {
    background: #ff0063;
    border-color: #ff0063;
    :before {
      content: "Unfollow";
    }
  }
`;
