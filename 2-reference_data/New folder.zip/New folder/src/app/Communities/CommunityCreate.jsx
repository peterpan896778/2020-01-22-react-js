import React from 'react';
import { withRouter } from 'react-router-dom';
import { useMutation } from '@apollo/react-hooks';
import { Formik, Form, Field } from 'formik';
import { gql } from 'apollo-boost';
import * as yup from 'yup';

import Input from 'common/UI/Input/Input';
// import AvatarPicker from 'common/UI/AvatarPicker/AvatarPicker';
import { GET_COMMUNITIES } from './CommunitiesBar/CommunitiesBar';

import * as S from './styled';

const CREATE_COMMUNITY = gql`
  mutation createCommunity(
    $name: String!,
    $url: String!,
    $description: String,
    $isPrivate: Boolean,
  ) {
    createCommunity(
      name: $name,
      url: $url,
      description: $description,
      isPrivate: $isPrivate,
    ) {
      url
    }
  }
`;
// image: $image,
// $image: Upload!,

// const UPLOAD = gql`
//   mutation singleUpload($file: Upload!) {
//     singleUpload(file: $file) {
//       id
//       path
//     }
//   }
// `;

const CreateCommunity = ({ history }) => {
  // const [upload] = useMutation(UPLOAD);
  const [createCommunity] = useMutation(
    CREATE_COMMUNITY,
    {
      update(cache, { data: { createCommunity: community } }) {
        const { communities } = cache.readQuery({ query: GET_COMMUNITIES });
        cache.writeQuery({
          query: GET_COMMUNITIES,
          data: { communities: communities.concat([community]) },
        });
      }
    }
  );
  const initialValues = {
    name: '',
    description: '',
    image: '',
    url: '',
    isPrivate: false,
  };

  const validationSchema = yup.object().shape({
    name: yup
      .string()
      .max(22, 'Must be shorter than 22 characters')
      .matches(/^\S+$/, 'Must contain no spaces')
      .matches(/^[^.]+$/, 'Must contain no dots')
      .required('Name is required'),
    url: yup
      .string()
      .matches(/^([a-zA-Z0-9.-]+)$/, 'Must not contain special characters')
      .required('Url is required'),
    // image: yup.string().required('Image is required'),
  });

  const onSubmit = async (values, { setSubmitting, setErrors }) => {
    const { data, error } = await createCommunity({
      variables: {
        ...values,
        image: 'https://voicestory.com/image/article/1566410146060channel6.png'
      },
      errorPolicy: 'all'
    });

    setSubmitting(false);
    if (!data) {
      setErrors({ name: 'Channel with this name or url already exists' });
    } else {
      const { createCommunity: { url: communityUrl } } = data;
      history.push(`/${communityUrl}/general`);
    }
  };

  return (
    <div className="content create-community-wrapper">
      <div className="create-community">
        <S.Back onClick={() => history.goBack()} />
        <h1>Create community</h1>
        <p>Communities are where your member.</p>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
          validateOnChange={false}
        >
          {({ isSubmitting }) => (
            <Form>
              {/*
              <Field
                type="file"
                name="image"
                label="Choose an avatar"
                tip="You can choose or create your own avatar 320x320 px"
                onChange={async ({
                  target: {
                    validity,
                    files: [file]
                  }
                }) => {
                  console.log('file');
                  console.log(file);
                  console.log('file');
                  upload({ variables: { file } })
                }}
                component={AvatarPicker}
              />
              */}
              <Field
                type="text"
                name="name"
                label="Name"
                tip="Names must be without spaces or periods and shorter than 22 characters."
                placeholder="#community"
                component={Input}
              />
              <Field
                type="text"
                name="description"
                label="Description"
                tip="What’s this community about?"
                placeholder="For example: Why UX and UI should remain separate"
                component={Input}
              />
              <Field
                type="text"
                name="url"
                label="Workspace URL"
                placeholder="community"
                urlMask=".voicestory.com"
                component={Input}
                validate={() => {}
                  // agent.Club.validateUrl(value).then((res) => {
                  //   if (res.club) {
                  //     // eslint-disable-next-line
                  //     throw 'Already taken';
                  //   }
                  // })
                }
              />
              <footer>
                <button
                  type="submit"
                  name="button"
                  disabled={isSubmitting}
                >
                  Create community
                </button>
                <button
                  type="button"
                  name="button"
                  onClick={() => history.goBack()}
                >
                  Cancel
                </button>
              </footer>
            </Form>
          )}
        </Formik>
      </div>
      <S.Illustration />
    </div>
  );
};


export default withRouter(CreateCommunity);
