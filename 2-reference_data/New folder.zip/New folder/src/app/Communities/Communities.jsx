import React, { useState, useContext } from 'react';
import { useHistory, Link } from 'react-router-dom';
import { useQuery, useMutation } from '@apollo/react-hooks';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { gql } from 'apollo-boost';
import { BlockstackContext } from 'context/BlockstackContext';

import * as S from './styled';

export const GET_COMMUNITIES = gql`
  query searchCommunities($searchString: String) {
    searchCommunities(searchString: $searchString) {
      id
      url
      image
      name
      description
      followers {
        id
      }
    }
  }
`;

export const FOLLOW_COMMUNITY = gql`
  mutation followCommunity($url: String) {
    followCommunity(url: $url) {
      id
      followers {
        id
      }
    }
  }
`;

export const UNFOLLOW_COMMUNITY = gql`
  mutation unfollowCommunity($url: String) {
    unfollowCommunity(url: $url) {
      id
      followers {
        id
      }
    }
  }
`;


const CommunitiesList = ({ searchString }) => {
  const {
    data: {
      searchCommunities: communities = [],
    } = {},
    // loading
  } = useQuery(GET_COMMUNITIES, {
    variables: { searchString }
  });
  const { user, loading: isUserLoading } = useContext(BlockstackContext);
  const [followCommunity] = useMutation(FOLLOW_COMMUNITY);
  const [unfollowCommunity] = useMutation(UNFOLLOW_COMMUNITY);

  const isFollowingCommunity = community => {
    if (community.followers.map(c => c.id).indexOf(user.id) > -1) {
      return true;
    }
    return false;
  };

  const onFollow = (isFollowing, url) => {
    if (isFollowing) {
      unfollowCommunity({ variables: { url } });
    } else {
      followCommunity({ variables: { url } });
    }
  };

  if (isUserLoading) {
    return (
      <div>loading...</div>
    );
  }

  return (
    <PerfectScrollbar className="communities-list">
      {communities.map(community => {
        const isFollowing = isFollowingCommunity(community);

        return (
          <div
            className="communities-list__row"
            key={community.id}
          >
            <img src={community.image} className="community__photo" alt="" />
            <div className="community-info">
              <Link to={`/${community.url}/general`}>
                {community.name}
              </Link>
              <p>{community.description}</p>
            </div>
            <div className="checkbox">
              <input
                type="checkbox"
                id={`checkbox-${community.id}`}
                checked={isFollowing}
              />
              {/* eslint-disable jsx-a11y/label-has-associated-control */}
              <label
                htmlFor={`checkbox-${community.id}`}
                label="Follow"
                onClick={() => onFollow(isFollowing, community.url)}
              />
              {/* eslint-enable jsx-a11y/label-has-associated-control */}
            </div>
          </div>
        );
      })}
    </PerfectScrollbar>
  );
};

const CommunitiesPage = () => {
  const [searchString, setSearchString] = useState('');
  const history = useHistory();

  return (
    <S.Container className="content communities-wrapper" style={{ justifyContent: 'center' }}>
      <button
        type="button"
        className="page-back"
        name="button"
        onClick={() => history.goBack()}
      >
        Back
      </button>
      <div className="communities" style={{ margin: '51px 0 auto 0' }}>
        <h1>Communities</h1>

        <p>You can and invite your friends</p>

        <input
          type="text"
          value={searchString}
          placeholder="Search"
          onChange={({ target: { value } }) => setSearchString(value)}
        />
        <CommunitiesList searchString={searchString} />
        <footer>
          <button
            type="button"
            name="button"
            onClick={() => history.push('/new-community')}
          >
            New community
          </button>
        </footer>
      </div>
    </S.Container>
  );
};

export default CommunitiesPage;
