import React, { useContext } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';
import { BlockstackContext } from 'context/BlockstackContext';

import CommunityPopup from '../CommunityPopup/CommunityPopup';
import CommunitiesBarPlaceholder from './CommunitiesBarPlaceholder';

export const GET_COMMUNITIES = gql`
  query communities {
    communities {
      id
      url
      image
      author {
        id
      }
      followers {
        id
      }
    }
  }
`;


const CommunitiesBar = () => {
  const {
    data: { communities = [] } = {},
    loading: isCommunitiesLoading
  } = useQuery(GET_COMMUNITIES);
  const {
    user,
    loading: isUserLoading
  } = useContext(BlockstackContext);
  const { communityUrl } = useParams();
  const history = useHistory();

  const isFollowing = community => {
    if (community.followers.map(c => c.id).indexOf(user.id) > -1) {
      return true;
    }
    return false;
  };

  if (isUserLoading || isCommunitiesLoading) {
    return (
      <CommunitiesBarPlaceholder />
    );
  }

  return (
    <div className="left-channels">
      {communities.map((community, index) => isFollowing(community) &&
        <div className="community-popup__wrapper" key={community.id}>
          <CommunityPopup id={community.id} />
          <button
            id={`left-community${index}`}
            type="button"
            name="button"
            className={community.url === communityUrl ? 'active' : ''}
            onClick={() => history.push(`/${community.url}/general`)}
          >
            <img src={community.image} className="community__photo" alt="" />
          </button>
        </div>
      )}
      <button
        type="button"
        aria-label="Add community"
        className="add-channel"
        name="button"
        onClick={() => history.push('/communities')}
      />
    </div>
  );
  // return (
  //   <S.Container>
  //     {communities.map((forum, index) =>
  //       <S.CommunityWrapper>
  //         <S.Community onClick={() => {}}>
  //           <S.CommunityImage src={forum.image} />
  //         </S.Community>
  //       </S.CommunityWrapper>
  //     )}
  //     <S.AddCommunity onClick={() => {}} />
  //   </S.Container>
  // );
};

export default CommunitiesBar;
