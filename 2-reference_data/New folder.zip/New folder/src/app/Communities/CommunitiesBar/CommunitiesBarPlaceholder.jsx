import React from 'react';
import ContentLoader from 'react-content-loader';

const CommunitiesPlaceholder = () => (
  <div className="left-channels">
    <ContentLoader
      height={250}
      width={69}
      speed={1}
      primaryColor="#eeeeee"
      secondaryColor="#f0f0f0"
    >
      <rect x="16.5" y="10" rx="5" ry="5" width="36" height="36" />
      <rect x="16.5" y="66" rx="5" ry="5" width="36" height="36" />
      <rect x="16.5" y="122" rx="5" ry="5" width="36" height="36" />
      <rect x="16.5" y="178" rx="5" ry="5" width="36" height="36" />
    </ContentLoader>
  </div>
);

export default CommunitiesPlaceholder;
