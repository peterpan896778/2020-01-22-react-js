import React from 'react';
import ContentLoader from 'react-content-loader';

const NavbarPlaceholder = () => (
  <ContentLoader
    width={85}
    height={700}
    speed={1}
    primaryColor="#242056"
    secondaryColor="#201b4e"
  >
    <rect x="24.5" y="16" rx="20" ry="20" width="36" height="36" />
    <rect x="24.5" y="73" rx="20" ry="20" width="36" height="36" />
    <rect x="24.5" y="131" rx="20" ry="20" width="36" height="36" />
    <rect x="22.5" y="239" rx="20" ry="20" width="40" height="118" />
    <rect x="24.5" y="430" rx="26" ry="26" width="36" height="36" />
    <rect x="24.5" y="488" rx="26 " ry="26" width="36" height="36" />
    <rect x="19" y="639" rx="6" ry="6" width="49" height="49" />
  </ContentLoader>
);

export default NavbarPlaceholder;
