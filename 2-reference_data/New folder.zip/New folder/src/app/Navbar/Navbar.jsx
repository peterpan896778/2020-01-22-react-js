import React, { useState, useContext } from 'react';
import { withRouter } from 'react-router-dom';
import { BlockstackContext } from 'context/BlockstackContext';
import { getUsername } from 'helpers';

import ProfilePopup from './ProfilePopup/ProfilePopup';
import Notifications from './Notifications/Notifications';
import NavbarPlaceholder from './NavbarPlaceholder';
import * as S from './styled';


const Navbar = ({
  unreadMessagesCount = 0,
  unreadNotificationsCount = 0,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const {
    user,
    loading: userLoading,
    isLogged: isAuthorized
  } = useContext(BlockstackContext);

  return (
    <>
      <S.Container>
        <S.Logo to="/" />

        {userLoading ?
          <NavbarPlaceholder />
          :
          <>
            <S.HomeIcon to="/" />
            <S.Messages>
              <S.MessagesIcon to="/direct" />
              {unreadMessagesCount > 0 &&
                <S.UnreadCountBadge>
                  {unreadMessagesCount}
                </S.UnreadCountBadge>
              }
            </S.Messages>
            {user &&
              <S.Notifications onClick={() => setShowNotifications(!showNotifications)}>
                <S.NotificationsIcon />
                {unreadNotificationsCount > 0 &&
                  <S.UnreadCountBadge>
                    {unreadNotificationsCount}
                  </S.UnreadCountBadge>
                }
              </S.Notifications>
            }
            <S.ExploreButton to="/communities">
              <S.Explore>
                Explore
              </S.Explore>
            </S.ExploreButton>
            {isAuthorized &&
              <S.HelpIcon to="/help" />
            }
            {isAuthorized &&
              <S.SettingsIcon to="/settings" />
            }
            {isAuthorized ?
              <S.Profile
                src={user.image}
                data-toggle="dropdown"
                name={getUsername(user)}
              />
              :
              <S.EmptyProfile />
            }
            <ProfilePopup />
          </>
        }
      </S.Container>
      <Notifications
        opened={showNotifications}
        close={(() => setShowNotifications(false))}
      />
    </>
  );
};

export default withRouter(Navbar);
