import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { BlockstackContext } from 'context/BlockstackContext';

import { getUsername } from 'helpers';
import Avatar from 'common/Avatar/Avatar';

const ProfilePopupComponent = () => {
  const {
    user,
    isLogged: isAuthorized,
    logout
  } = useContext(BlockstackContext);

  return (
    <div className="profile-popup user-dropdown-menu dropdown-menu">
      {isAuthorized ?
        <>
          <header>
            <Avatar
              name={getUsername(user)}
              src={user.image}
              round={3}
              style={{
                width: 36,
                height: 36,
                borderRadius: 3,
              }}
            />
            <p>
              {getUsername(user)}
            </p>
          </header>
          {/*
            <button
              className="new-post"
              onClick={() => history.push(newPostLink)}
              New post
            </button>
            >
          */}
          <ul>
            <Link to="/communities">
              <li>Communities</li>
            </Link>
            <Link to={`/@${getUsername(user)}`}>
              <li>Profile</li>
            </Link>
            <Link to="/settings">
              <li>Settings</li>
            </Link>
            <Link
              to="/login"
              onClick={logout}
            >
              <li>Sign out</li>
            </Link>
            {/*
            <BlockStackProfile />
            */}
          </ul>
        </>
        :
        <>
          <div className="blank__user" />
          {/*
            <button className="new-post" onClick={() => history.push(newPostLink)}>
              New post
            </button>
          */}
          <ul>
            <Link to="/login">
              <li>Login</li>
            </Link>
            <Link to="/communities">
              <li>Communities</li>
            </Link>
          </ul>
        </>
      }
    </div>
  );
};

export default ProfilePopupComponent;
