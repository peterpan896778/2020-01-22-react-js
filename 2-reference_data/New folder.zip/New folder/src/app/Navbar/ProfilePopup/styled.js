import styled from 'styled-components';

import A from 'common/Avatar/Avatar';

export const Container = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  display: none;
  float: left;
  min-width: 10rem;
  padding: .5rem 0;
  margin: .125rem 0 0;
  font-size: 1rem;
  color: #212529;
  text-align: left;
  list-style: none;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid rgba(0,0,0,.15);
  border-radius: .25rem;

  top: 50px !important;
  left: 85px !important;
  padding: 0px !important;

  display: none;
  width: 298px;
  text-align: left;
  background: #fff;
  box-shadow: 0 20px 60px 0 rgba(6,8,37, 0.06);
  border-radius: 6px;
  border: 1px solid #e2e2e2;
  position: fixed;
  z-index: 3;
  left: 103px;
  bottom: 25px;
  &.show {
    display: block;
  }
`;

export const Header = styled.header`
  display: flex;
  align-items: center;
  padding: 16px 20px;
`;

export const Avatar = styled(A).attrs({
  alt: 'Avatar'
})`
  border-radius: 3px;
  width: 36px;
  height: 36px;
  margin-right: 15px;
  margin-top: -1px;
`;

export const Name = styled.p`
  font-family: Helvetica Neue Cyr Bold;
  font-size: 22px;
  color: #1d1c1d;
  height: 28px;
  display: flex;
  align-items: center;
  white-space: nowrap;
  cursor: pointer;
`;

export const List = styled.ul`
  font-family: Helvetica Neue Cyr Roman;
  font-size: 15px;
  color: #1d1c1d;
  line-height: 30px;
  border-top: 1px solid #e2e2e2;
  padding: 12px 9px;
`;

export const ListItem = styled.li`
  height: 30px;
  border-radius: 5px;
  padding: 0 8px;
  cursor: pointer;
  transition: all .2s ease-in-out;
`;
