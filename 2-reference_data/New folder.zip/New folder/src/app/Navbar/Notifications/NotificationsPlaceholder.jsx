import React from 'react';

import * as S from './styled';

const NotificationsPlaceholder = ({ opened, close }) => (
  <S.Container opened={opened}>
    <S.Header>
      <S.Title>
        Notifications
      </S.Title>
      <S.Close onClick={close} />
    </S.Header>
  </S.Container>
);

export const NotificationsEmpty = ({ opened, close }) => (
  <S.Container opened={opened}>
    <S.Header>
      <S.Title>
        Notifications
      </S.Title>
      <S.Close onClick={close} />
    </S.Header>
    <S.NotificationsEmptyContainer>
      <S.NotificationsEmptyImage />
      <S.NotificationsEmptyHeading>
        No one’s around to play with Wumpus.
      </S.NotificationsEmptyHeading>
      <S.NotificationsEmptyParagraph>
        Your friend can write you a message
      </S.NotificationsEmptyParagraph>
    </S.NotificationsEmptyContainer>
  </S.Container>
);

export default NotificationsPlaceholder;
