import React, { useState, useEffect, useContext } from 'react';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';
import { BlockstackContext } from 'context/BlockstackContext';
import { getUsername } from 'helpers';

import notificationSound from 'assets/sounds/notification.wav';
import Notification from './Notification/Notification';
import NotificationsPlaceholder, { NotificationsEmpty } from './NotificationsPlaceholder';
import * as S from './styled';

const NotificationSound = new Audio(notificationSound);

export const GET_NOTIFICATIONS = gql`
  query notifications($sentToUser: String) {
    notifications(sentToUser: $sentToUser) {
      id
      type
      createdAt
      message {
        body
        author {
          id
          username
        }
      }
    }
  }
`;

export const NOTIFICATIONS_SUBSCRIPTION = gql`
  subscription newNotification($sentToUser: String) {
    newNotification(sentToUser: $sentToUser) {
      id
      type
      createdAt
      message {
        body
        author {
          id
          username
        }
      }
    }
  }
`;


const Notifications = ({ opened, close }) => {
  const [subscribed, setSubscribed] = useState(false);
  const {
    user,
    loading: userLoading,
  } = useContext(BlockstackContext);
  const {
    data: { notifications = [] } = {},
    loading: notificationsLoading,
    subscribeToMore
  } = useQuery(GET_NOTIFICATIONS, {
    variables: { sentToUser: getUsername(user) }
  });

  useEffect(() => {
    if (user && !subscribed) {
      subscribeToMore({
        document: NOTIFICATIONS_SUBSCRIPTION,
        variables: { sentToUser: getUsername(user) },
        updateQuery: (prev, { subscriptionData }) => {
          if (!subscriptionData.data) return prev;
          const { newNotification } = subscriptionData.data;
          NotificationSound.play();

          return {
            ...prev,
            notifications: [newNotification, ...prev.notifications]
          };
        }
      });
      setSubscribed(true);
    }
  }, [user]);

  if (userLoading || notificationsLoading) {
    return (
      <NotificationsPlaceholder opened={opened} close={close} />
    );
  }

  if (false) {
    return (
      <NotificationsEmpty opened={opened} close={close} />
    );
  }

  return (
    <S.Container opened={opened}>
      <S.Header>
        <S.Title>
          Notifications
          <S.Count>
            {notifications.length}
          </S.Count>
        </S.Title>
        <S.MarkAsRead>
          Mark all read
        </S.MarkAsRead>
        <S.Close onClick={close} />
      </S.Header>

      <S.NotificationsWrapper>
        {notifications.map(notification =>
          <Notification
            key={notification.id}
            notification={notification}
          />
        )}
      </S.NotificationsWrapper>

    </S.Container>
  );
};


export default Notifications;
