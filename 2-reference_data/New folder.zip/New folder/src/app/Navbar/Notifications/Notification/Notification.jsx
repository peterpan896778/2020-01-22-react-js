import React from 'react';
import moment from 'moment';

import { transformMentions } from '../../../../helpers';
import * as S from './styled';

const getAction = action => ({
  mention: 'mentioned you',
}[action]);

const Notification = ({ notification }) => (
  <S.Container>
    <S.AvatarWrapper>
      <S.Avatar
        src={notification.message.author.image}
        name={notification.message.author.username}
      />
    </S.AvatarWrapper>
    <S.Info>
      <S.Title>
        <S.Name>
          {notification.message.author.username}
        </S.Name>
        <S.Action>
          {` ${getAction(notification.type)}`}
        </S.Action>
      </S.Title>
      <S.Body>
        {transformMentions(notification.message.body)}
      </S.Body>
      {notification.actions &&
        <S.Actions>
          {notification.actions.map(action =>
            <S.Button onClick={() => {}}>
              {action.name}
            </S.Button>
          )}
          <S.Button cancel>
            Cancel
          </S.Button>
        </S.Actions>
      }
      <S.Footer>
        <S.Date>
          {moment(notification.createdAt).format('h:mm A')}
        </S.Date>
        <S.Link>
          View message
        </S.Link>
      </S.Footer>
    </S.Info>
  </S.Container>
);

export default Notification;
