import styled from 'styled-components';
import mention from 'icons/@.svg';
import CommonAvatar from 'common/Avatar/Avatar';

export const Container = styled.div`
  display: flex;
  align-items: flex-start;
  text-align: left;
  border-bottom: 1px solid #e8e8e8;
  padding: 21px 30px 17px;
  :hover {
    background: #f8f8f8;
  }
`;

export const AvatarWrapper = styled.div`
  width: 30px;
  height: 30px;
  position: relative;
  :after {
  content: "";
    display: flex;
    width: 14px;
    height: 14px;
    background-image: url(${mention});
    background-size: cover;
    border-radius: 50%;
    position: absolute;
    right: -4px;
    bottom: -3px;
  }
`;

export const Avatar = styled(CommonAvatar).attrs({
  alt: 'Avatar'
})`
  width: 100%;
  height: 100%;
  border-radius: 3px;
  overflow: hidden;
`;

export const Info = styled.div`
  max-width: calc(100% - 45px);
  font-family: "Helvetica Neue Cyr Roman";
  margin-left: 15px;
`;

export const Title = styled.p`
  font-size: 15px;
  color: #131313;
  line-height: 22px;
`;

export const Name = styled.a`
  font-family: "Helvetica Neue Cyr Medium";
  color: inherit;
`;

export const Action = styled.span`
`;

export const Body = styled.p`
  font-size: 15px;
  color: #131313;
  line-height: 22px;
`;

// export const Mention = styled.a`
// `;

export const Actions = styled.div`
  display: flex;
  align-items: center;
  margin-top: 10px;
`;

export const Button = styled.button.attrs({
  type: 'button'
})`
  height: 24px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 13px;
  color: #fff;
  line-height: 24px;
  background: #5c24d4;
  border-radius: 5px;
  border: 1px solid #5c24d4;
  padding: 0 9px;
  :hover {
    background: #34378b;
  }
  :active {
    background: #212464;
  }
  ${props => props.cancel && `
    color: #000;
    background: #fff;
    border-color: #bababa;
    margin-left: 5px;
    :hover {
      background: #f6f6f6;
    }
    :active {
      background: #e6e4e4;
    }
  `}
`;

export const Footer = styled.footer`
  display: flex;
  align-items: center;
  margin-top: 20px;
`;

export const Date = styled.span`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 13px;
  color: #1d1c1d;
  margin-right: 8px;
  :after {
    content: "";
    display: inline-block;
    width: 1px;
    height: 13px;
    background: #cdcdcd;
    margin-left: 8px;
    margin-bottom: -2px;
  }
`;

export const Link = styled.a`
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 13px;
  cursor: pointer;
  color: #1264a3 !important;
  :hover {
    text-decoration: underline !important;
  }
`;
