/* eslint-disable */
import React from 'react';

const Notification2 = () => (
  <div>
    Notification2
  </div>
);

// const getType = action => ({
//   mention: 'mentioned you:',
// }[action]);

// const getAction = action => {
//   switch (action) {
//     case 'mention':
//       return 'mentioned you:';
//     case 'invite':
//       break;
//     case 'request':
//     case 'cancellation':
//     case 'sending':
//     case 'respond':
//       break;
//     default:
//       break;
//   }
// };

// const getType = type => {
//   switch (type) {
//     case 'friend':
//       break;
//     case 'interview':
//     case 'message':
//     case 'respond':
//       break;
//     default:
//       break;
//   }
// };

// const notifications = [
//   {
//     type: 'interview',
//     action: 'invite',
//     body: 'Hey @ton! The type of work that I do is basically just lots of different types of illustrations. It ranges in subjectmatter as well as in content.',
//     actions: [
//       {
//         name: 'Confirm'
//       }
//     ],
//     date: 'Aug 24, 2018',
//     author: {
//       username: 'Vladimir'
//     }
//   }
// ];
// <S.Container>
//   <S.AvatarWrapper>
//     <img src="http://mish-sanek.online/v5_helvetica/img/notification-user1.png" alt="" />
//   </S.AvatarWrapper>
//   <div className="notification-block__info">
//     <p className="about">
//       <a href="#">Vladimir @mentioned</a> you:
//     </p>
//     <p className="description">
//       Hey <a href="#">@ton!</a> The type of work that I do is basically just lots of different types of illustrations. It ranges in subjectmatter as well as in content.
//     </p>
//     <div className="notification-block__actions">
//       <button type="button" name="button">Confirm</button>
//       <button type="button" name="button">Cancel</button>
//     </div>
//     <footer>
//       <span>Aug 24, 2018</span>
//       <a href="#">Check interview</a>
//     </footer>
//   </div>
// </S.Container>
// <div className="notification-block">
//   <div className="notification-block__user responded">
//     <img src="http://mish-sanek.online/v5_helvetica/img/notification-user2.png" alt="" />
//   </div>
//   <div className="notification-block__info">
//     <p className="about">
//       <a href="#">Gleb Kuznetsov</a> responded to a new interview
//     </p>
//     <p className="description">
//       I do my most productive work when I’m in something called flow.
//     </p>
//     <ul className="emotions">
//       <li>
//         <em>😰</em>
//         <span>9</span>
//       </li>
//     </ul>
//     <footer>
//       <span>Jul 29, 2018</span>
//       <a href="#">View message</a>
//     </footer>
//   </div>
// </div>
// <div className="notification-block">
//   <div className="notification-block__user">
//     <img src="http://mish-sanek.online/v5_helvetica/img/notification-user3.png" alt="" />
//   </div>
//   <div className="notification-block__info">
//     <p className="about">
//       <a href="#">George Bokhua</a> sent a request to add to friends
//     </p>
//     <p className="description">
//       Hello! I would like to add you as a friend
//     </p>
//     <div className="notification-block__actions">
//       <button type="button" name="button">Add</button>
//       <button type="button" name="button">Cancel</button>
//     </div>
//     <footer>
//       <span>Jul 16, 2018</span>
//       <a href="#">View profile</a>
//     </footer>
//   </div>
// </div>
// {/* notification block end */}
// {/* notification block */}
// <div className="notification-block">
//   <div className="notification-block__user">
//     <img src="http://mish-sanek.online/v5_helvetica/img/notification-user4.png" alt="" />
//   </div>
//   <div className="notification-block__info">
//     <p>
//       <a href="#">Ben Stafford</a> sent you a private message
//     </p>
//     <p className="description">
//       Hello! I would like to add you as a friend
//     </p>
//     <div className="notification-block__actions">
//       <button type="button" name="button">Answer</button>
//       <button type="button" name="button">Ignore</button>
//     </div>
//     <footer>
//       <span>Jun 22, 2018</span>
//       <a href="#">View message</a>
//     </footer>
//   </div>
// </div>
// {/* notification block end */}
// {/* notification block */}
// <div className="notification-block">
//   <div className="notification-block__user">
//     <img src="http://mish-sanek.online/v5_helvetica/img/notification-user5.png" alt="" />
//   </div>
//   <div className="notification-block__info">
//     <p className="about">
//       <a href="#">
//         Leo Natsume
//       </a>
//       <span className="cancelled">
//         canceled
//       </span> an interview request with
//       <a href="#">
//         you
//       </a>
//     </p>
//     <p className="description">
//       Sorry dude I will be available in 4 months
//     </p>
//     <ul className="emotions">
//       <li>
//         <em>😡</em>
//         <span>12</span>
//       </li>
//     </ul>
//     <footer>
//       <span>Jun 21, 2018</span>
//       <a href="#">View message</a>
//     </footer>
//   </div>
// </div>


export default Notification2;
