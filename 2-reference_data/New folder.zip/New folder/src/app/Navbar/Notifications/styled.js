import styled from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';

import notificationsEmpty from 'assets/images/illustrations/empty-chat.png';
import close from 'icons/close.svg';
import closeHover from 'icons/close-hover.svg';

// eslint-disable-next-line
export const Container = styled.div`
  width: 449px;
  height: 100%;
  background: #fff;
  border-right: 1px solid #d5d5d5;
  box-shadow: 0 10px 50px 0 rgba(6,8,37, 0.06);
  opacity: 0;
  position: fixed;
  left: -500px;
  top: 0;
  z-index: 4;
  overflow: hidden;
  transition: left 0.2s ease-in-out, opacity 0.2s ease-in-out;
  ${props => props.opened && `
    opacity: 1;
    left: 85px;
  `}
`;

export const Header = styled.header`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 35px 30px 0;
`;

export const Title = styled.p`
  display: flex;
  align-items: center;
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 17px;
  color: #1d1c1d;
  margin-right: auto;
`;

export const Count = styled.span`
  display: inline-block;
  height: 16px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 12px;
  color: #fff;
  line-height: 17px;
  background: #f45151;
  border-radius: 9px;
  padding: 0 8px;
  margin-top: -2px;
  margin-left: 10px;
`;

export const MarkAsRead = styled.button.attrs({
  type: 'button'
})`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 14px;
  color: #484848;
  margin-right: 15px;
  margin-bottom: -1px;
  :hover {
    text-decoration: underline;
  }
`;

export const Close = styled.button.attrs({
  type: 'button'
})`
  width: 13px;
  height: 13px;
  background-image: url(${close});
  background-size: cover;
  position: relative;
  :hover {
    background-image: url(${closeHover});
  }
`;

export const NotificationsWrapper = styled(PerfectScrollbar)`
  height: calc(100% - 96px);
  margin-top: 45px;
  overflow-y: auto;
`;

export const NotificationsEmptyContainer = styled.div`
  width: 100%;
  height: calc(100% - 200px);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

export const NotificationsEmptyImage = styled.img.attrs({
  alt: 'Empty',
  src: notificationsEmpty
})`
  width: 400px;
`;

export const NotificationsEmptyHeading = styled.h1`
  font-family: Helvetica Neue Cyr Bold;
  font-size: 15px;
  color: #1d1c1d;
  margin-top: 70px;
`;

export const NotificationsEmptyParagraph = styled.p`
  font-family: Helvetica Neue Cyr Roman;
  font-size: 14px;
  color: #868686;
  margin-top: 12px;
`;
