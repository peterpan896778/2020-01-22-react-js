import styled from 'styled-components';
import { Link } from 'react-router-dom';

import HomeSVG from 'icons/home.svg';
import MessagesSVG from 'icons/messages.svg';
import NotificationsSVG from 'icons/notifications.svg';
import HelpSVG from 'icons/help.svg';
import SettingsSVG from 'icons/settings.svg';
import LogoSVG from 'icons/logo.png';

import Avatar from 'common/Avatar/Avatar';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 85px;
  height: 100vh;
  background: #16123e;
  z-index: 5;
`;

export const Logo = styled(Link)`
  cursor: pointer;
  display: block;
  width: 85px;
  height: 85px;
  min-height: 85px;
  background-image: url("${LogoSVG}");
  background-repeat: no-repeat;
  background-size: 30px 29px;
  background-position: center;
  outline: none;
`;

const Icon = styled(Link)`
  cursor: pointer;
  transition: opacity 0.2s ease-in-out;
  opacity: 0.4;
  background-repeat: no-repeat;
  :hover {
    opacity: 1;
  }
  :active {
    opacity: 0.2;
  }
`;

export const HomeIcon = styled(Icon)`
  width: 26px;
  height: 26px;
  margin-top: 21px;
  background-image: url(${HomeSVG});
  background-size: contain;
`;

export const Messages = styled.div`
  position: relative;
  margin-top: 31px;
`;

export const MessagesIcon = styled(Icon)`
  margin-left: 1px;
  width: 25px;
  height: 25px;
  display: block;
  background-image: url(${MessagesSVG});
  background-size: contain;
`;

export const UnreadCountBadge = styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 16px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 12px;
  color: #fff;
  text-align: center;
  line-height: 17px;
  background: #f45151;
  border-radius: 9px;
  padding: 0 7px;
  position: absolute;
  right: -10px;
  top: -6px;
`;

export const Notifications = styled.div`
  position: relative;
  margin-top: 33px;
`;

export const NotificationsIcon = styled.a`
  cursor: pointer;
  transition: opacity 0.2s ease-in-out;
  opacity: 0.4;
  background-repeat: no-repeat;
  :hover {
    opacity: 1;
  }
  :active {
    opacity: 0.2;
  }
  width: 25px;
  height: 25px;
  display: block;
  background-image: url(${NotificationsSVG});
  background-size: cover;
`;

export const ExploreButton = styled(Link)`
  width: 40px;
  height: 118px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 15px;
  color: #16123e;
  background: #fff;
  white-space: nowrap;
  border-radius: 30px;
  margin-top: 76px;
  position: relative;
  cursor: pointer;
  :hover {
    opacity: 0.8;
  }
  :active {
    opacity: 1;
    background: #e6e4e4;
  }
`;

export const Explore = styled.span`
  position: absolute;
  user-select: none;
  left: -17px;
  bottom: 53px;
  -webkit-transform: rotate(-90deg);
  -ms-transform: rotate(-90deg);
  transform: rotate(-90deg);
  :after {
    content: "";
    display: inline-block;
    width: 10px;
    height: 10px;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='20px' height='20px'%3e%3cpath fill-rule='evenodd' fill='rgb(22, 18, 62)' d='M18.425,11.667 L11.696,11.667 L11.696,18.422 C11.696,19.294 10.990,20.000 10.119,20.000 L9.941,20.000 C9.069,20.000 8.363,19.294 8.363,18.422 L8.363,11.667 L1.575,11.667 C0.705,11.667 -0.000,10.962 -0.000,10.092 L-0.000,9.908 C-0.000,9.038 0.705,8.333 1.575,8.333 L8.363,8.333 L8.363,1.578 C8.363,0.706 9.069,0.000 9.941,0.000 L10.119,0.000 C10.990,0.000 11.696,0.706 11.696,1.578 L11.696,8.333 L18.425,8.333 C19.295,8.333 20.000,9.038 20.000,9.908 L20.000,10.092 C20.000,10.962 19.295,11.667 18.425,11.667 Z'/%3e%3c/svg%3e");
    background-size: cover;
    margin-left: 12px;
  }
`

export const HelpIcon = styled(Icon)`
  width: 25px;
  height: 25px;
  margin-top: 81px;
  background-image: url(${HelpSVG});
  background-size: contain;
`;

export const SettingsIcon = styled(Icon)`
  width: 26px;
  height: 26px;
  margin-top: 31px;
  background-image: url(${SettingsSVG});
  background-size: contain;
`;

// background-image: url(${props => props.src || getAvatar(props.name)});
// background-size: cover;
// background-position: center center;
export const Profile = styled(Avatar)`
  cursor: pointer;
  width: 49px;
  height: 49px;
  border-radius: 6px;
  border: 1px solid transparent;
  border: 1px solid #16113e;
  position: absolute;
  left: 18px;
  bottom: 25px;
  :hover {
    border-color: #34378b;
  }
  :after {
    content: "";
    display: block;
    width: 10px;
    height: 10px;
    background: #2bbb72;
    border-radius: 50%;
    border: 2px solid #16123e;
    position: absolute;
    right: -4px;
    bottom: -4px;
    box-sizing: content-box;
  }
`;
export const EmptyProfile = styled.button`
  cursor: pointer;
  width: 49px;
  height: 49px;
  border-radius: 6px;
  border: 1px solid transparent;
  border: 1px solid #16113e;
  position: absolute;
  left: 18px;
  bottom: 25px;
  :hover {
    border-color: #34378b;
  }
  :after {
    content: "";
    display: block;
    width: 10px;
    height: 10px;
    background: #2bbb72;
    border-radius: 50%;
    border: 2px solid #16123e;
    position: absolute;
    right: -4px;
    bottom: -4px;
    box-sizing: content-box;
  }
  background-color: #16123e;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='45' height='50'%3E%3Cpath fill-rule='evenodd' fill='%238E9EB3' d='M44.711 37.545a19.793 19.793 0 01-1.515 2.244c-.786 1.066-1.684 2.02-2.582 2.917a24.613 24.613 0 01-2.581 2.245C33.601 48.261 28.27 50 22.771 50c-5.499 0-10.829-1.739-15.262-5.049-.898-.73-1.795-1.459-2.581-2.245a21.242 21.242 0 01-2.581-2.917c-.505-.673-1.066-1.459-1.515-2.244-.169-.337-.225-.73-.056-1.066.336-.786.785-1.628 1.29-2.357a15.856 15.856 0 0111.054-6.957c.561-.112 1.178.056 1.627.393 2.357 1.739 5.162 2.637 8.08 2.637s5.724-.898 8.08-2.637c.449-.337 1.066-.449 1.627-.393 4.489.617 8.473 3.142 11.054 6.957.505.729.954 1.515 1.291 2.357.168.336.112.729-.168 1.066zM22.827 26.211c-7.07 0-12.849-5.778-12.849-12.848C9.978 6.294 15.757.515 22.827.515s12.849 5.779 12.849 12.848c0 7.07-5.779 12.848-12.849 12.848z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-size: 22px 25px;
  background-position: 50%;
  border: 1px solid #2e2a52;
  border-radius: 6px;
  :after {
    content: none;
  }
`;
export const Bottom = styled.div`
  position: absolute;
  bottom: 23px;
  width: 85px;
`;
