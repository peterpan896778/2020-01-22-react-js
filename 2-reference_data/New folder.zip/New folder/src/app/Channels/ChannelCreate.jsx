import React from 'react';
import { withRouter, useParams } from 'react-router-dom';
import { useMutation } from '@apollo/react-hooks';
import { Formik, Form, Field } from 'formik';
import { gql } from 'apollo-boost';
import * as yup from 'yup';

import Input from 'common/UI/Input/Input';
import { GET_CHANNELS } from '../RightBar/Channels/Channels';
// import AvatarPicker from 'common/UI/AvatarPicker/AvatarPicker';

import * as S from './styled';

const CREATE_CHANNEL = gql`
  mutation createChannel(
    $name: String!,
    $url: String!,
    $communityUrl: String!,
    $description: String,
    $isPrivate: Boolean,
  ) {
    createChannel(
      name: $name,
      url: $url,
      description: $description,
      isPrivate: $isPrivate,
      communityUrl: $communityUrl,
    ) {
      id
      name
      url
    }
  }
`;

const initialValues = {
  name: '',
  description: '',
  // image: '',
  isPrivate: false,
};

const validationSchema = yup.object().shape({
  name: yup
    .string()
    .lowercase('Must be lowercase').strict()
    .max(22, 'Must be shorter than 22 characters')
    .matches(/^[^.]+$/, 'Must contain no dots')
    .required('Name is required'),
});

const CreateChannel = ({ history }) => {
  const { communityUrl } = useParams();
  const [createChannel] = useMutation(
    CREATE_CHANNEL,
    {
      update(cache, { data: { createChannel: channel } }) {
        const { channels } = cache.readQuery({
          query: GET_CHANNELS,
          variables: {
            communityUrl
          }
        });
        cache.writeQuery({
          query: GET_CHANNELS,
          variables: { communityUrl },
          data: { channels: channels.concat([channel]) },
        });
      }
    }
  );

  const onSubmit = async (values, { setSubmitting, setErrors }) => {
    const url = values.name.toLowerCase().replace(' ', '-');
    const { data } = await createChannel({
      variables: {
        communityUrl,
        url,
        ...values
      },
      errorPolicy: 'all'
    });

    setSubmitting(false);
    if (!data) {
      setErrors({ name: 'Channel with this name already exists' });
    } else {
      const { createChannel: { url: channelUrl } = {} } = data;
      history.push(`/${communityUrl}/${channelUrl}`);
    }
  };

  return (
    <div className="content create-community-wrapper">
      <div className="create-community">
        <S.Back onClick={() => history.goBack()} />
        <h1>Create a channel</h1>
        <p>Channels are where your member communicate.</p>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
          validateOnChange={false}
        >
          {({ isSubmitting }) => (
            <Form>
              {/*
              <Field
                type="file"
                name="image"
                label="Choose an avatar"
                tip="You can choose or create your own avatar 320x320 px"
                onChange={e => {
                  const fd = new FormData();
                  fd.append('fname', 'profile');
                  fd.append('data', e.target.files[0]);
                }}
                component={AvatarPicker}
              />
              */}
              <Field
                type="text"
                name="name"
                label="Name"
                tip="Names must be without periods and shorter than 22 characters."
                placeholder="fun"
                component={Input}
              />
              <Field
                type="text"
                name="description"
                label="Description"
                tip="What’s this channel about?"
                placeholder="For example: Why UX and UI should remain separate"
                component={Input}
              />
              <footer>
                <button
                  type="submit"
                  name="button"
                  disabled={isSubmitting}
                >
                  Create channel
                </button>
                <button
                  type="button"
                  name="button"
                  onClick={() => history.goBack()}
                >
                  Cancel
                </button>
              </footer>
            </Form>
          )}
        </Formik>
      </div>
      <S.Illustration />
    </div>
  );
};


export default withRouter(CreateChannel);
