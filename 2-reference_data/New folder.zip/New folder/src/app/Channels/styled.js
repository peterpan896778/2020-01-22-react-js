import styled from 'styled-components';

import newChannelBg from '../../assets/images/illustrations/new-channel-bg.png';
import back from '../../assets/images/icons/back.svg';

export const Illustration = styled.div`
  width: 50%;
  height: 100%;
  background-image: url(${newChannelBg});
  background-position: center;
  background-size: cover;
  position: fixed;
  right: 0;
  top: 0;
`;

export const Back = styled.button.attrs({
  type: 'button',
  ariaLabel: 'back'
})`
  width: 40px;
  height: 40px;
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 14px;
  color: #615f61;
  background-image: url(${back});
  background-size: 17px 12px;
  background-repeat: no-repeat;
  background-position: center;
  border-radius: 50%;
  border: 1px solid #d4dce2;
  margin-top: 53px;
  position: relative;
  box-sizing: border-box;
  :hover {
    background-color: #f6f6f6;
  }
  :active {
    background-color: #e6e4e4;
  }
`;
