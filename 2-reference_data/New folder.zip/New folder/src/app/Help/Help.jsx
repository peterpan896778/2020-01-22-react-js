import React from 'react';

const Help = () => (
  <div>
    Help
  </div>
);

export default Help;
