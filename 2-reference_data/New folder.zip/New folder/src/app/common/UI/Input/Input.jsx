import React from 'react';
import * as S from './styled';

const Input = ({
  field,
  form: { touched, errors },
  tip,
  label,
  placeholder,
  urlMask
}) => (
  <S.InputContainer>
    <S.Label>
      {label}
    </S.Label>
    <S.Input
      type="text"
      name={field.name}
      value={field.value}
      onChange={field.onChange}
      onBlur={field.onBlur}
      placeholder={placeholder}
    />
    {touched[field.name] && errors[field.name] &&
      <S.Error>
        {errors[field.name]}
      </S.Error>
    }
    {tip &&
      <S.Tip>
        {tip}
      </S.Tip>
    }
    {urlMask &&
      <S.UrlMask>
        {urlMask}
      </S.UrlMask>
    }
  </S.InputContainer>
);

export default Input;
