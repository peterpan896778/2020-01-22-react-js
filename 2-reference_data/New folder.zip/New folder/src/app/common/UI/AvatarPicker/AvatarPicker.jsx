import React from 'react';
import * as S from './styled';

const AvatarPicker = ({
  field,
  onChange,
  form: { touched, errors },
  tip,
  label,
}) => (
  <div className="create-community__avatar-block">
    <div className="create-community__avatar empty">
      <label htmlFor="create-community-image-upload">
        {field.value && <img alt="Avatar" src={field.value} />}
        <input
          type="file"
          id="create-community-image-upload"
          accept="image/*"
          onChange={onChange}
          style={{ display: 'none' }}
        />
      </label>
    </div>

    <div className="create-community__avatar-info">
      <p>{label}</p>
      <span>{tip}</span>

      <div className="create-community__avatar-type">
        <span>png</span>
        <span>jpg</span>
        <span>gif</span>
      </div>

      {touched[field.name] && errors[field.name] &&
        <S.Error>
          {errors[field.name]}
        </S.Error>
      }
    </div>
  </div>
);

export default AvatarPicker;
