import styled from 'styled-components';

// eslint-disable-next-line
export const Error = styled.div`
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 13px;
  color: #da3662;
  line-height: 20px;
  margin-top: 10px;
`;
