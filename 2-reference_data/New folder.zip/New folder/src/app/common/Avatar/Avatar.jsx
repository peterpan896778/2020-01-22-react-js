/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';

const getAvatar = (name) => new window.Pictogrify(name, 'monsters').base64;

const Avatar = ({
  name,
  src,
  style,
  ...props
}) => (
  <img
    alt="Avatar"
    src={src || getAvatar(name)}
    style={style}
    {...props}
  />
);

export default Avatar;
