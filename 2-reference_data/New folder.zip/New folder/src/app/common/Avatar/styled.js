import styled from 'styled-components';

// eslint-disable-next-line
export const Avatar = styled.img.attrs({
  alt: 'Avatar'
})`
  width: 36px;
  height: 36px;
  border-radius: 6px;
`;
