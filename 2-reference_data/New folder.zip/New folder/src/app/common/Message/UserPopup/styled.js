import styled from 'styled-components';
import DefaultAvatar from 'common/Avatar/Avatar';

// export const Container = styled.div`
//   width: 298px;
//   background: #fff;
//   box-shadow: 0 0 0 1px rgba(29,28,29, 0.13), 0 4px 12px 0 rgba(0,0,0,.08);
//   border-radius: 6px;
//   padding-bottom: 15px;
//   visibility: hidden;
//   opacity: 0;
//   position: absolute;
//   left: 51px;
//   z-index: -2;
//   transition: opacity 0.2s ease-in-out;

//   :after {
//     content: "";
//     display: block;
//     width: 50px;
//     height: 100%;
//     background: transparent;
//     position: absolute;
//     left: -50px;
//     top: 0;
//     z-index: 2;
//   }

//   ${props => props.opened && `
//     visibility: visible;
//     opacity: 1;
//     z-index: 2;
//   `}
// `;

export const Container = styled.div`
  width: 298px;
  background: #fff;
  box-shadow: 0 0 0 1px rgba(29,28,29, 0.13), 0 4px 12px 0 rgba(0,0,0,.08);
  border-radius: 6px;
  padding-bottom: 15px;
  transition: opacity 0.2s ease-in-out;
`;

export const Avatar = styled(DefaultAvatar).attrs({
  alt: 'Avatar'
})`
  width: 100%;
  border-top-left-radius: 6px;
  border-top-right-radius: 6px;
  overflow: hidden;
`;

// export const Close = styled.button.attrs({
//   type: 'button',

// })`
// `;

export const Header = styled.header`
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 22px;
  color: #1d1c1d;
  padding: 0 19px;
  margin-top: 20px;
`;

export const Name = styled.a`
  max-width: 100%;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  color: inherit;
`;

export const Info = styled.div`
  display: flex;
  padding: 0 19px;
  margin-top: 15px;
`;

export const InfoBlock = styled.div`
  :nth-child(2) {
    padding: 0 26px;
    margin: 0 30px 0 25px;
    position: relative;
    :before, :after {
      content: "";
      display: block;
      width: 1px;
      height: 13px;
      background: #e2e2e2;
      position: absolute;
      top: 13px;
      left: 0;
    }
    :after {
      left: auto;
      right: 0;
    }
  }
`;

export const Label = styled.span`
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 13px;
  color: #616061;
`;

export const Value = styled.p`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 15px;
  color: #1e1c1d;
  margin-top: 2px;
`;

export const Actions = styled.div`
  display: flex;
  align-items: center;
  padding: 0 19px;
  margin-top: 17px;
`;

export const Button = styled.button.attrs({
  type: 'button',
})`
  height: 36px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 15px;
  color: #1d1c1d;
  line-height: 37px;
  border-radius: 5px;
  border: 1px solid #bababa;
  padding: 0 19px;
  :hover {
    background: #f6f6f6;
  }
  :active {
    background: #e6e4e4;
  }
  :nth-child(2) {
    margin-left: 10px;
  }
`;

// export const MoreButton = styled.button`
// `;

