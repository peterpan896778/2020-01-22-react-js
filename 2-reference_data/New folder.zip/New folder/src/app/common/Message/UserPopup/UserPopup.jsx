import React from 'react';
import { useQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';

import * as S from './styled';

export const GET_USER = gql`
  query user($username: String) {
    user(username: $username) {
      id
      username
    }
  }
`;

const UserPopup = ({ username, opened, close }) => {
  const { data: { user } = {}, loading } = useQuery(GET_USER, {
    variables: { username }
  });

  if (loading) {
    return (
      <S.Container>
        loading...
      </S.Container>
    );
  }

  return (
    <S.Container
      opened={opened}
      onMouseOut={close}
    >
      <S.Avatar
        src={user.image}
        name={user.username}
      />
      <S.Header>
        <S.Name href="#">
          {user.username}
        </S.Name>
      </S.Header>
      <S.Info>
        <S.InfoBlock>
          <S.Label>
            Followers
          </S.Label>
          <S.Value>
            0
          </S.Value>
        </S.InfoBlock>
        <S.InfoBlock>
          <S.Label>
            Likes
          </S.Label>
          <S.Value>
            0
          </S.Value>
        </S.InfoBlock>
        <S.InfoBlock>
          <S.Label>
            Posts
          </S.Label>
          <S.Value>
            0
          </S.Value>
        </S.InfoBlock>
      </S.Info>
      <S.Actions>
        {/*
        <S.Button>
          Follow
        </S.Button>
        */}
        <S.Button>
          Message
        </S.Button>
      </S.Actions>
    </S.Container>
  );
};

export default UserPopup;
