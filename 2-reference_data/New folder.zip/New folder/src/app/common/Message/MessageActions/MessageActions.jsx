import React from 'react';

const MessageActions = () => {
  return (
    <div className="chat-message__actions">
      <button
        aria-label="Reply"
        type="button"
        className="chat-message__reply"
        name="button"
      />
      <i />
      <button
        aria-label="Emoji"
        type="button"
        className="chat-message__smile"
        name="button"
      />
      <i />
      <button
        aria-label="Edit"
        type="button"
        className="chat-message__edit"
        name="button"
      />
      <i />
      <button
        aria-label="More"
        type="button"
        className="chat-message__more"
        name="button"
      />
      <ul className="chat-message__more-window">
        <li>Copy link</li>
        <li>Mark unread</li>
        <li>Remind me about this</li>
        <li>Pin to #support</li>
        <li className="delete-message">Delete message</li>
        <li>Add a message action</li>
      </ul>
    </div>
  );
};

export default MessageActions;
