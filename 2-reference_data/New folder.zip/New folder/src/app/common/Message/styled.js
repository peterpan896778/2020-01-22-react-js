import styled from 'styled-components';

import DefaultAvatar from 'common/Avatar/Avatar';

// eslint-disable-next-line
export const Avatar = styled(DefaultAvatar).attrs({
  alt: 'Avatar'
})`
  width: 36px;
  height: 36px;
  border-radius: 6px;
`;
