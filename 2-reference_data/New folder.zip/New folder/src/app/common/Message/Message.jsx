/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import moment from 'moment';

import { transformMentions } from 'helpers';
import * as S from './styled';
// import MessageActions from './MessageActions/MessageActions';
// import UserPopup from './UserPopup/UserPopup';


const Message = ({ message, isChild }) => isChild ?
  <ChildMessage message={message} /> :
  <ParentMessage message={message} />;

const ChildMessage = ({ message }) => (
  <div className="chat-message queue">
    <div className="chat-message__info">
      <span className="chat-message__time">
        {moment(message.createdAt).fromNow()}
      </span>
      <div className="chat-message__text">
        {transformMentions(message.body)}
      </div>
    </div>
  </div>
);

const ParentMessage = ({ message }) => {
  // const [showUserPopup, setShowUserPopup] = useState(false);

  return (
    <div className="chat-message">
      <S.Avatar
        src={message.author.image}
        name={message.author.username}
      />
      {/*
      <UserPopup
        username={message.author.username}
        opened={showUserPopup}
        close={() => setShowUserPopup(false)}
      />
      */}
      <div className="chat-message__info">
        <p className="chat-message__user">
          <a>{message.author.username}</a>
          <span className="chat-message__time">
            {moment(message.createdAt).format('h:m A')}
          </span>
        </p>
        <p className="chat-message__text">
          {transformMentions(message.body)}
        </p>
      </div>
      {/*
      <MessageActions />
      */}
    </div>
  );
};

export default Message;
