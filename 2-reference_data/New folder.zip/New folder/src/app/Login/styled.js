import styled from 'styled-components';

import signInBg from '../../assets/images/illustrations/sign-in-bg.png';
import back from '../../assets/images/icons/back.svg';
import blockstack from '../../assets/images/icons/blockstack.svg';


// eslint-disable-next-line import/prefer-default-export
export const Container = styled.div`
  display: flex;
  flex-direction: row;
`;

export const Form = styled.div`
  flex: 1;
  padding: 0 134px;
  width: 50vw;
  max-width: 50vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

export const Back = styled.button.attrs({
  type: 'button',
  ariaLabel: 'back'
})`
  margin: 53px 0;
  width: 40px;
  height: 40px;
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 14px;
  color: #615f61;
  background-image: url(${back});
  background-size: 17px 12px;
  background-repeat: no-repeat;
  background-position: center;
  border-radius: 50%;
  border: 1px solid #d4dce2;
  margin-top: 53px;
  position: relative;
  box-sizing: border-box;
  :hover {
    background-color: #f6f6f6;
  }
  :active {
    background-color: #e6e4e4;
  }
`;

export const Heading = styled.h1`
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 29px;
  color: #1d1c1d;
`;

export const Paragraph = styled.p`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 15px;
  color: #131313;
  margin-top: 18px;
`;

export const Image = styled.div`
  flex: 1;
  width: 50vw;
  height: 100vh;
  background-image: url(${signInBg});
  background-position: center;
  background-size: cover;
`;

export const Button = styled.button.attrs({
  type: 'button'
})`
  width: 350px;
  height: 50px;
  font-family: "Helvetica Neue Cyr Medium";
  font-size: 15px;
  color: #fff;
  background: #5c24d4;
  border-radius: 6px;
  margin-top: 67px;
  :hover {
    background-color: #5a5dc0;
  }
  :active {
    background-color: #212464;
  }
  :before {
    content: "";
    display: inline-block;
    width: 17px;
    height: 17px;
    background-image: url(${blockstack});
    background-size: cover;
    margin-right: 10px;
    margin-bottom: -3px;
  }
`;
