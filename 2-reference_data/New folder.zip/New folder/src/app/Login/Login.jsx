import React, { useContext, useEffect } from 'react';
import { withRouter } from 'react-router-dom';

import { BlockstackContext } from 'context/BlockstackContext';
import * as S from './styled';

const SignIn = ({ history }) => {
  const { signInWithBlockstack, BlockStackSession } = useContext(BlockstackContext);

  useEffect(() => {
    if (BlockStackSession.isUserSignedIn()) {
      history.push('/voicestory/general');
    }
  }, []);

  return (
    <S.Container>
      <S.Form>
        <div />
        {/* document.referrer !== '' ?
          <S.Back onClick={() => history.goBack()} />
          : <div />
        */}
        <div style={{ marginTop: -150 }}>
          <S.Heading>
            Sign In
          </S.Heading>
          <S.Paragraph>
            To continue, Log In to VoiceStory
          </S.Paragraph>
          <S.Button onClick={signInWithBlockstack}>
            Continue with Blockstack
          </S.Button>
        </div>
        <i />
      </S.Form>
      <S.Image />
    </S.Container>
  );
};

export default withRouter(SignIn);
