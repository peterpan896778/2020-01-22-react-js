import React from 'react';
import { withRouter } from 'react-router-dom';

import * as S from './styled';

const FeedActions = ({
  onSearch = () => {},
  onFavorite = () => {},
  history,
}) => {
  const isFavorite = false;

  // const params = location.pathname.split('/');
  // let newPostLink = '/v/common/create-post';
  // if (location.pathname.indexOf('/v/') > -1) {
  //   newPostLink = `/v/${params[2]}/create-post`;
  // }

  return (
    <div className="chat-header__actions">
      {/*
      <button
        type="button"
        aria-label="Search"
        className="search"
        onClick={onSearch}
      />
      <S.PopupWrapper>
        <button
          type="button"
          aria-label="Settings"
          className="settings"
          data-toggle="dropdown"
        />
        <S.Popup popup="settings">
          <li>Settings</li>
          <li>Requests</li>
          <li>Chat archive</li>
          <li>Unread chats</li>
          <hr />
          <li>Report a problem</li>
        </S.Popup>
      </S.PopupWrapper>
      <button
        type="button"
        aria-label="Info"
        className="info"
      />
      <button
        type="button"
        aria-label="Favorite"
        className={`add-favorite ${isFavorite ? 'favorite' : ''}`}
        onClick={onFavorite}
      />
      <S.PopupWrapper>
        <button
          type="button"
          aria-label="More"
          className="chat-header__more-btn"
          data-toggle="dropdown"
        />
        <S.Popup popup="more">
          <li className="add">Add user</li>
          <li className="attach">Show attachment</li>
          <li className="find">Find a message in history</li>
          <hr />
          <li className="notifications">Enable notifications</li>
          <li className="clear">Clear message history</li>
          <li className="leave">Leave the chat</li>
        </S.Popup>
      </S.PopupWrapper>
      */}
      <S.NewPostBtn onClick={() => history.push('/voicestory/feed/new-post')}>

        New Post
      </S.NewPostBtn>
    </div>
  );
};

export default withRouter(FeedActions);
