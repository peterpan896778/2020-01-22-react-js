import React from 'react';
import { FlatFeed } from 'react-activity-feed';

import FeedHeader from './FeedHeader';
import FeedItem from './FeedItem/FeedItem';
import * as S from './styled';

const Feed = () => {
  return (
    <S.Container>
      <FeedHeader />
      <S.FeedContainer>
        <FlatFeed
          feedGroup="Voicestory"
          Activity={FeedItem}
        />
      </S.FeedContainer>
    </S.Container>
  );
};

export default Feed;
