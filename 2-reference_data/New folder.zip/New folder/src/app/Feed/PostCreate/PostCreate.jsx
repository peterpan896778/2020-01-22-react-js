import React from 'react';
import { StatusUpdateForm } from 'react-activity-feed';

// import stream from 'getstream';

// const token = localStorage.getItem('GetStreamToken');
// const apiKey = '8jmp5zsmnnew';
// const appId = '61446';

// const client = stream.connect(apiKey, token, appId);
// const ignatife = client.feed('Voicestory', 'ignatife');
// ignatife.addActivity({
//   actor: 'ignatife',
//   verb: 'add',
//   object: 'picture:10',
//   foreign_id: 'picture:10',
//   message: 'Beautiful bird!'
// }).then(
//   null, // nothing further to do
//   function(err) {
//     // Handle or raise the Error.
//   }
// );

const PostCreate = () => (
  <StatusUpdateForm
    feedGroup="Voicestory"
    userId="ignatife"
  />
);

export default PostCreate;
