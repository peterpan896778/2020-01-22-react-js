import React from 'react';
import FeedActions from './FeedActions';

const FeedHeader = () => {
  const community = {
    image: 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-img5.png',
    name: 'Voicestory',
    description: 'Talking bout bitcoints here'
  };

  return (
    <div className="content-header__wrapper">
      <header className="content-header" style={{ justifyContent: 'space-between' }}>
        <div className="content-header__left">
          <img src={community.image} alt="Community avatar" />
          <div className="content-header__info">
            <span className="info__name">{community.name}</span>
            <p>
              <span className="users-count">{19}</span>
              <span>{community.description}</span>
            </p>
          </div>
        </div>
        <FeedActions />
      </header>
    </div>
  );
};

export default FeedHeader;
