import React from 'react';

const Posts = () => (
  <div>
    Posts
  </div>
);

export default Posts;
