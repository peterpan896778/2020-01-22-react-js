import styled from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';

import add from '../../assets/images/icons/popup/add.svg';
import attach from '../../assets/images/icons/popup/attach.svg';
import find from '../../assets/images/icons/popup/find.svg';
import notifications from '../../assets/images/icons/popup/notifications.svg';
import clear from '../../assets/images/icons/popup/clear.svg';
import leave from '../../assets/images/icons/popup/leave.svg';


// eslint-disable-next-line import/prefer-default-export
export const FeedContainer = styled(PerfectScrollbar).attrs({
  className: 'feeds'
})`
  width: 748px;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  margin: 0 auto;
  max-height: calc(100vh - 73px);
`;

export const Container = styled.div`
  width: 100%;
  position: relative;
`;

// Actions

export const PopupWrapper = styled.div.attrs({
  className: 'content-header__settings-wrapper dropdown'
})`
  height: 36px;
  display: flex;
  align-items: center;
  position: relative;
`;

export const Popup = styled.ul.attrs({
  className: 'content-header__settings-popup dropdown-menu dropdown-menu-right'
})`
  width: 248px;
  background: #fff;
  border-radius: 6px;
  border: 1px solid #d9d9d9;
  box-shadow: 0 10px 20px 0 rgba(1, 1, 5, 0.1);
  padding: 11px 0 12px;
  position: absolute;
  transition: opacity 0.2s ease-in-out;

  top: 6px !important;

  visibility: hidden;
  opacity: 0;
  z-index: -2;

  &.show {
    visibility: visible;
    opacity: 1;
    z-index: 3;
  }
  li {
    font-family: "Helvetica Neue Cyr Roman";
    font-size: 15px;
    color: #131313;
    line-height: 28px;
    padding-left: 25px;
    cursor: pointer;
    margin-left: 0 !important;
    :hover {
      background: #34378b;
      color: #fff;
    }
  }
  li.add:before {
    content: '';
    width: 15px;
    height: 15px;
    background-image: url(${add});
    margin-right: 13px;
    margin-bottom: -3px;
    display: inline-block;
    background-size: cover;
  }
  li.attach:before {
    content: '';
    width: 16px;
    height: 15px;
    background-image: url(${attach});
    margin-right: 11px;
    margin-bottom: -3px;
    display: inline-block;
    background-size: cover;
  }
  li.find:before {
    content: '';
    width: 14px;
    height: 15px;
    background-image: url(${find});
    margin-right: 12px;
    margin-bottom: -2px;
    display: inline-block;
    background-size: cover;
  }
  li.notifications:before {
    content: '';
    width: 12px;
    height: 16px;
    background-image: url(${notifications});
    margin-right: 14px;
    margin-bottom: -3px;
    display: inline-block;
    background-size: cover;
  }
  li.clear:before {
    content: '';
    width: 11px;
    height: 14px;
    background-image: url(${clear});
    margin-right: 15px;
    margin-bottom: -2px;
    display: inline-block;
    background-size: cover;
  }
  li.leave:before {
    content: '';
    width: 14px;
    height: 14px;
    background-image: url(${leave});
    margin-right: 15px;
    margin-bottom: -2px;
    display: inline-block;
    background-size: cover;
  }
  hr {
    display: block;
    unicode-bidi: isolate;
    margin-block-start: 0.5em;
    margin-block-end: 0.5em;
    margin-inline-start: auto;
    margin-inline-end: auto;
    overflow: hidden;
  }
`;

export const NewPostBtn = styled.button.attrs({
  type: 'button',
  ariaLabel: 'New post'
})`
  font-family: "Helvetica Neue Cyr Medium";
  height: 36px;
  font-size: 15px;
  color: #fff;
  line-height: 38px;
  background: #34378b;
  border-radius: 5px;
  padding: 0 14px;
  margin-left: 15px;
  :hover {
    background: #5a5dc0;
  }
  :active {
    background: #212464;
  }
`;
