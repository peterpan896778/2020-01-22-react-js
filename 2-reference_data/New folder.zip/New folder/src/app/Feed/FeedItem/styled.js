import styled from 'styled-components';
import { Link } from 'react-router-dom';

export const FeedBlock = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-end;

  width: 363px;
  height: 278px;
  padding: 20px;
  margin-top: 22px;
  border-radius: 10px;
  color: white;
  overflow: hidden;
  position: relative;
  cursor: pointer;

  background: linear-gradient(
    0deg,
    rgba(22,18,62,0.6),
    rgba(22,18,62,0.6)
  ), url("${props => props.img}");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;

  :not(:nth-child(odd)) {
    margin-left: 18px;
  }
`;

export const Date = styled.span`
  font-family: "Helvetica Neue Cyr Roman";
  font-size: 12px;
  margin-bottom: auto;
`;

export const Title = styled.a`
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 18px;
  color: inherit;
  line-height: 27px;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  cursor: pointer;
`;

export const User = styled.p`
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  margin-top: 18px;
`;

export const UserImage = styled.img.attrs({
  alt: 'Avatar'
})`
  width: 36px;
  height: 36px;
  border-radius: 6px;
  overflow: hidden;
`;

export const UserName = styled(Link)`
  font-family: "Helvetica Neue Cyr Bold";
  font-size: 14px;
  color: inherit;
  margin-left: 11px;
  margin-bottom: -4px;
`;
