import React from 'react';
import { withRouter } from 'react-router-dom';

import * as S from './styled';

const FeedItem = ({ activity, history }) => {
  const img = 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-img5.png';
  const articleUrl = 'how_to_do_something';
  const authorImg = 'http://mish-sanek.online/v5_helvetica/img/feeds-img/feeds4-user5.png';
  // const communityUrl = 'voicestory';

  const formatDate = (date) => {
    return '9:34 AM';
  }

  return (
    <S.FeedBlock
      img={img}
      onClick={() => history.push(`feed/${articleUrl}`)}
    >
      <S.Date>
        {formatDate(activity.time)}
      </S.Date>
      <S.Title>
        {activity.object}
      </S.Title>
      <S.User>
        <S.UserImage src={authorImg} />
        <S.UserName to={`/@${activity.actor.id}`}>
          {activity.actor.id}
        </S.UserName>
      </S.User>
    </S.FeedBlock>
  );
};

export default withRouter(FeedItem);
