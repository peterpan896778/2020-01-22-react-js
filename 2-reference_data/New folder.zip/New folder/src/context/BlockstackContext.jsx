import React, { useState, useEffect, createContext } from 'react';
import { useMutation, useLazyQuery } from '@apollo/react-hooks';
import { gql } from 'apollo-boost';
import { UserSession, AppConfig } from 'blockstack';

const BlockstackContext = createContext();
const { Provider, Consumer } = BlockstackContext;

const BlockStackConfig = new AppConfig();
const BlockStackSession = new UserSession({ appConfig: BlockStackConfig });

const LOGIN = gql`
  mutation login($username: String!) {
    login(username: $username) {
      token
      user {
        id
        username
      }
    }
  }
`;

const GET_USER = gql`
  query me {
    me {
      id
      username
    }
  }
`;

const wait = ms => new Promise(resolve => setTimeout(() => resolve(ms), ms));

const BlockstackProvider = ({ children }) => {
  const [loading, setLoading] = useState(true);

  const [user, setUser] = useState(null);
  const [getUser, { data: { me } = {} }] = useLazyQuery(GET_USER);
  const [isLogged, setLogged] = useState(BlockStackSession.isUserSignedIn());

  const signInWithBlockstack = () => BlockStackSession.redirectToSignIn();

  const [login] = useMutation(LOGIN);
  const logout = () => {
    BlockStackSession.signUserOut();
    localStorage.removeItem('token');
  };

  useEffect(() => {
    if (user) {
      const newUser = { ...user, ...me };
      setUser(newUser);
    }
  }, [me]);

  useEffect(() => {
    // If login is in progress (step after redirection from blockstack)
    if (BlockStackSession.isSignInPending()) {
      BlockStackSession.handlePendingSignIn().then(async (bsUser) => {
        const {
          data: {
            login: {
              token,
              user: userObject
            }
          }
        } = await login({
          variables: { username: bsUser.username.split('.')[0] }
        });
        await localStorage.setItem('token', token);
        await wait(1000);
        await setUser({ ...bsUser, ...userObject });
        await setLogged(true);
        window.history.replaceState({}, document.title, '/voicestory/general');
        setLoading(false);
      });
    } else if (isLogged) {
      const getUserData = async () => {
        const bsUser = await BlockStackSession.loadUserData();
        await getUser();
        await setUser(bsUser);
        setLoading(false);
      };
      getUserData();
    }
  }, []);

  return (
    <Provider
      value={{
        BlockStackSession,
        signInWithBlockstack,
        user,
        loading,
        isLogged,
        logout
      }}
    >
      {children}
    </Provider>
  );
};

export { BlockstackProvider as default, Consumer as BlockstackConsumer, BlockstackContext };
