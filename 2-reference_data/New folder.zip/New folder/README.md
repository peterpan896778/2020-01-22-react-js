## Frontend
```
yarn && yarn start
```

## Backend
```
cd server && yarn
prisma2 dev
yarn dev
```

### Seed database
```
rm -r prisma/migrations/ && rm prisma/dev.db
yarn seed
```
