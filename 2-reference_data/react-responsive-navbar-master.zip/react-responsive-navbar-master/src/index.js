import ResponsiveNavbar from './responsive-navbar.component';

export default ResponsiveNavbar;
