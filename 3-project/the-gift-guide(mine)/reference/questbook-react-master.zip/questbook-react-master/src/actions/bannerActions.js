import types from './types';

export const dismissBanner = () => ({
  type: types.BANNER.BANNER_DISMISS
});
