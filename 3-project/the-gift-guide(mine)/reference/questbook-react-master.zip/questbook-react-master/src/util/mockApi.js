export const mockApi = {};
