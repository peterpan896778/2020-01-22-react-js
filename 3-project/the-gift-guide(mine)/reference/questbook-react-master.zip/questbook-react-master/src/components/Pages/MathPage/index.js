export { default } from './MathPage';
