export { default } from './DiagnosticTestHeader';
