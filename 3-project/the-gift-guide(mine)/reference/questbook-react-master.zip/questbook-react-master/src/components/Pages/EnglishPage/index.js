export { default } from './EnglishPage';
