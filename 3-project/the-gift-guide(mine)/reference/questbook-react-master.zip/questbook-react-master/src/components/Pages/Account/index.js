import React, { Component } from "react";
import { AccountPassword } from "./AccountPassword";
import { AccountProfile } from "./AccountProfile";
import { AccountPayments } from "./AccountPayments";

export { AccountPassword, AccountProfile, AccountPayments };
