export { default } from './DiagnosticTestEndCardPage';
