export { default } from './DiagnosticTestBodySection';
