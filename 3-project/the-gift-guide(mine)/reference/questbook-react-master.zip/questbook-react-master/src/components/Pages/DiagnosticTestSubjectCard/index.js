export { default } from './DiagnosticTestSubjectCard';
