export { default } from './SciencePage';
