export { default } from './StudyMaterialPage';
