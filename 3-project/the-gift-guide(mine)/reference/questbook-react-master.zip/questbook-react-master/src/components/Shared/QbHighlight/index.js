import QbHighlight from './QbHighlight';

export default QbHighlight;
