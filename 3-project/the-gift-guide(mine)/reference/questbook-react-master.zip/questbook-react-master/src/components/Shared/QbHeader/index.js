import QbHeader from './QbHeader';
import QbSimpleHeader from './QbSimpleHeader';
import QbAvatar from './QbAvatar';
export {QbHeader as default, QbSimpleHeader, QbAvatar};
