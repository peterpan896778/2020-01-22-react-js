export const study_material_content = {
  study_material: {
    title: "Study Material",
    description: "Read through this short guide so you’ll know what to expect on test day. You'll find the insider tips, and test-taking strategies"
  }
}
