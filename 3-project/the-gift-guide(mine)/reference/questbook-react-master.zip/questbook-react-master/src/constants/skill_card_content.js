export const skill_card_content = {
  math: {
    title: "Math",
    image: "math.png",
    required_time: 30,
  },
  science: {
    title: "Science",
    image: "science.png",
    required_time: 20,
  },
  reading: {
    title: "Reading",
    image: "reading.png",
    required_time: 20,
  },
  english: {
    title: "English",
    image: "english.png",
    required_time: 20,
  },
  readingwriting: {
    title: "Reading",
    image: "reading.png",
    required_time: 20,
  }
}
