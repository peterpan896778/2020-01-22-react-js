export const APP_ENV = {
  nextDateACT: [
    {
      label: "July 14, 2018",
      value: "2018-07-14"
    },
    {
      label: "September 8, 2018",
      value: "2018-09-08"
    },
    {
      label: "October 27, 2018",
      value: "2018-10-27"
    },
    {
      label: "December 8, 2018",
      value: "2018-12-08"
    },
    {
      label: "February 9, 2019",
      value: "2019-02-09"
    }
  ],
  nextDateSAT: [
    {
      label: "August 25, 2018",
      value: "2018-08-25"
    },
    {
      label: "Octuber 6, 2018",
      value: "2018-10-06"
    },
    {
      label: "November 3, 2018",
      value: "2018-11-03"
    },
    {
      label: "December 1, 2018",
      value: "2018-12-01"
    },
    {
      label: "March 9, 2019",
      value: "2019-03-09"
    }
  ]
};
